package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AuditTimelineDialog
import com.example.ui.components.CompriFyTopBar
import com.example.ui.screens.*
import com.example.ui.theme.CompriFyTheme
import com.example.ui.viewmodel.CompriFyViewModel

enum class Screen(val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    HOME("Início", Icons.Filled.Home, Icons.Outlined.Home),
    LISTS("Compras", Icons.Filled.FormatListBulleted, Icons.Outlined.FormatListBulleted),
    CATALOG("Catálogo", Icons.Filled.Category, Icons.Outlined.Category),
    PRICE_COMPARE("Comparar", Icons.Filled.PriceCheck, Icons.Outlined.PriceCheck),
    BUDGET("Orçamento", Icons.Filled.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet),
    RECURRENCE("Recorrências", Icons.Filled.Repeat, Icons.Outlined.Repeat),
    WISHLIST("Desejos", Icons.Filled.Favorite, Icons.Outlined.FavoriteBorder),
    WIDGETS("Widgets", Icons.Filled.Widgets, Icons.Outlined.Widgets),
    HISTORY("Histórico", Icons.Filled.History, Icons.Outlined.History),
    SETTINGS("Espaço", Icons.Filled.Settings, Icons.Outlined.Settings)
}

class MainActivity : ComponentActivity() {

    private val viewModel: CompriFyViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            CompriFyTheme {
                MainApp(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(viewModel: CompriFyViewModel) {
    var currentScreen by remember { mutableStateOf(Screen.HOME) }
    var inShoppingModeListId by remember { mutableStateOf<String?>(null) }
    var showMoreMenu by remember { mutableStateOf(false) }

    val currentProfile by viewModel.currentProfile.collectAsStateWithLifecycle()
    val shoppingLists by viewModel.shoppingLists.collectAsStateWithLifecycle()
    val selectedListId by viewModel.selectedListId.collectAsStateWithLifecycle()
    val selectedList by viewModel.selectedList.collectAsStateWithLifecycle()
    val selectedListItems by viewModel.selectedListItems.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()
    val budgets by viewModel.budgets.collectAsStateWithLifecycle()
    val purchases by viewModel.purchases.collectAsStateWithLifecycle()
    val prices by viewModel.prices.collectAsStateWithLifecycle()
    val recurrences by viewModel.recurrences.collectAsStateWithLifecycle()
    val wishlist by viewModel.wishlist.collectAsStateWithLifecycle()
    val activityLogs by viewModel.activityLogs.collectAsStateWithLifecycle()
    val auditDialogState by viewModel.auditDialogState.collectAsStateWithLifecycle()
    val selectedAuditLogs by viewModel.selectedAuditLogs.collectAsStateWithLifecycle()
    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUserMessage()
        }
    }

    // Back handling
    if (inShoppingModeListId != null) {
        BackHandler {
            inShoppingModeListId = null
        }
    } else if (currentScreen != Screen.HOME) {
        BackHandler {
            currentScreen = Screen.HOME
        }
    }

    Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing),
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                if (inShoppingModeListId == null) {
                    CompriFyTopBar(currentProfile = currentProfile)
                }
            },
            bottomBar = {
                if (inShoppingModeListId == null) {
                    NavigationBar {
                        val primaryScreens = listOf(
                            Screen.HOME to Icons.Outlined.Home,
                            Screen.LISTS to Icons.Outlined.FormatListBulleted,
                            Screen.CATALOG to Icons.Outlined.Category,
                            Screen.BUDGET to Icons.Outlined.AccountBalanceWallet
                        )
                        primaryScreens.forEach { (screen, icon) ->
                            NavigationBarItem(
                                selected = currentScreen == screen,
                                onClick = { currentScreen = screen },
                                icon = { Icon(imageVector = if (currentScreen == screen) screen.selectedIcon else icon, contentDescription = screen.title) },
                                label = { Text(screen.title, maxLines = 1) },
                                alwaysShowLabel = true
                            )
                        }
                        NavigationBarItem(
                            selected = currentScreen !in primaryScreens.map { it.first },
                            onClick = { showMoreMenu = true },
                            icon = { Icon(Icons.Filled.MoreHoriz, contentDescription = "Mais opções") },
                            label = { Text("Mais") },
                            alwaysShowLabel = true
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (inShoppingModeListId != null) {
                    val listForMode = shoppingLists.find { it.id == inShoppingModeListId } ?: selectedList
                    ShoppingModeScreen(
                        list = listForMode,
                        items = selectedListItems,
                        currentProfile = currentProfile,
                        onUpdateCartItem = { itemId, qty, price, inCart ->
                            viewModel.updateItemInCart(itemId, qty, price, inCart)
                        },
                        onFinalizeCheckout = { store, subtotal, discount, finalAmt, cashierAmt, method, installments, notes, itemsData ->
                            viewModel.finalizePurchase(
                                listId = inShoppingModeListId,
                                budgetId = listForMode?.budgetId,
                                storeName = store,
                                itemsSubtotal = subtotal,
                                discountTotal = discount,
                                finalAmount = finalAmt,
                                cashierReportedAmount = cashierAmt,
                                paymentMethod = method,
                                installments = installments,
                                notes = notes,
                                purchasedItemsData = itemsData,
                                onSuccess = {
                                    inShoppingModeListId = null
                                }
                            )
                        },
                        onBack = { inShoppingModeListId = null }
                    )
                } else {
                    when (currentScreen) {
                        Screen.HOME -> HomeScreen(
                            selectedList = selectedList,
                            listItems = selectedListItems,
                            budgets = budgets,
                            purchases = purchases,
                            recurrences = recurrences,
                            activityLogs = activityLogs,
                                currentProfile = currentProfile,
                            onNavigateToListDetail = { listId ->
                                viewModel.selectList(listId)
                                currentScreen = Screen.LISTS
                            },
                            onStartShoppingMode = { listId ->
                                viewModel.selectList(listId)
                                inShoppingModeListId = listId
                            },
                            onNavigateToCatalog = { currentScreen = Screen.CATALOG },
                            onNavigateToPrices = { currentScreen = Screen.PRICE_COMPARE },
                            onNavigateToBudget = { currentScreen = Screen.BUDGET },
                            onNavigateToRecurrences = { currentScreen = Screen.RECURRENCE },
                            onNavigateToWishlist = { currentScreen = Screen.WISHLIST },
                            onNavigateToWidgets = { currentScreen = Screen.WIDGETS },
                            onNavigateToHistory = { currentScreen = Screen.HISTORY }
                        )

                        Screen.LISTS -> ShoppingListsScreen(
                            lists = shoppingLists,
                            selectedListId = selectedListId,
                            budgets = budgets,
                            products = products,
                            listItems = selectedListItems,
                            onSelectList = { viewModel.selectList(it) },
                            onCreateList = { name, desc, type, bId ->
                                viewModel.createShoppingList(name, desc, type, bId)
                            },
                            onDeleteList = { viewModel.deleteShoppingList(it) },
                            onStartShoppingMode = { listId ->
                                viewModel.selectList(listId)
                                inShoppingModeListId = listId
                            },
                            onAddItemToList = { listId, pId, name, cat, brand, qty, unit, price, priority, img, emoji, aisle ->
                                viewModel.addItemToList(listId, pId, name, cat, brand, qty, unit, price, priority, img, emoji, aisle)
                            },
                            onUpdateQuantity = { id, delta ->
                                viewModel.updateListItemQuantity(id, delta)
                            },
                            onDeleteItem = { viewModel.deleteListItem(it) },
                            onOpenAudit = { entityId, entityName ->
                                viewModel.openAudit(entityId, entityName)
                            }
                        )

                        Screen.CATALOG -> CatalogScreen(
                            products = products,
                            onCreateProduct = { name, cat, brand, unit, img, emoji, aisle ->
                                viewModel.createProduct(name, cat, brand, unit, img, emoji, aisle)
                            }
                        )

                        Screen.PRICE_COMPARE -> PriceComparisonScreen(
                            prices = prices,
                            products = products,
                            onAddPrice = { pId, pName, store, price, unit ->
                                viewModel.addPrice(pId, pName, store, price, unit)
                            }
                    )

                    Screen.BUDGET -> BudgetScreen(
                        budgets = budgets,
                        purchases = purchases,
                        onCreateBudget = { name, type, amt, thresh ->
                            viewModel.createBudget(name, type, amt, thresh)
                        }
                    )

                    Screen.RECURRENCE -> RecurrenceScreen(
                        recurrences = recurrences,
                        onCreateRecurrence = { name, cat, days, label, qty, unit, store, refPrice ->
                            viewModel.createRecurrence(name, cat, days, label, qty, unit, store, refPrice)
                        },
                        onPostpone = { id, days ->
                            viewModel.postponeRecurrence(id, days)
                        },
                        onAddToList = { name, qty, unit, price ->
                            val listId = selectedListId ?: shoppingLists.firstOrNull()?.id
                            if (listId != null) {
                                viewModel.addItemToList(
                                    listId = listId,
                                    productId = "rec_prod_${System.currentTimeMillis()}",
                                    name = name,
                                    category = "Recorrência",
                                    brand = "",
                                    quantity = qty,
                                    unit = unit,
                                    estimatedPrice = price,
                                    priority = "Alta"
                                )
                                currentScreen = Screen.LISTS
                            }
                        }
                    )

                    Screen.WISHLIST -> WishlistScreen(
                        wishlist = wishlist,
                        lists = shoppingLists,
                        onAddWishlistItem = { name, cat, price, priority, notes ->
                            viewModel.addWishlistItem(name, cat, price, priority, notes)
                        },
                        onMoveToList = { item, targetListId ->
                            viewModel.moveWishlistItemToList(item, targetListId)
                            viewModel.selectList(targetListId)
                            currentScreen = Screen.LISTS
                        },
                        onDelete = { viewModel.deleteWishlistItem(it) }
                    )

                    Screen.WIDGETS -> WidgetsPreviewScreen(
                        activeList = selectedList,
                        items = selectedListItems,
                        budgets = budgets,
                        purchases = purchases,
                        recurrences = recurrences,
                        onToggleItemInCart = { itemId, currentStatus ->
                            val inCart = currentStatus != "No Carrinho"
                            viewModel.updateItemInCart(itemId, 1.0, 0.0, inCart)
                        },
                        onQuickAddProduct = { name, qty ->
                            val listId = selectedListId ?: shoppingLists.firstOrNull()?.id
                            if (listId != null) {
                                viewModel.addItemToList(
                                    listId = listId,
                                    productId = "quick_${System.currentTimeMillis()}",
                                    name = name,
                                    category = "Alimentação",
                                    brand = "",
                                    quantity = qty,
                                    unit = "un",
                                    estimatedPrice = 0.0,
                                    priority = "Média"
                                )
                            }
                        }
                    )

                    Screen.HISTORY -> HistoryScreen(
                        logs = activityLogs,
                        purchases = purchases,
                    )

                    Screen.SETTINGS -> SettingsScreen(
                        currentProfile = currentProfile,
                        onExportBackup = { viewModel.exportBackup(it) },
                        onImportBackup = { viewModel.importBackup(it) },
                        onUpdateProfileName = { viewModel.updateLocalProfileName(it) }
                    )
                }
            }
        }
    }

    if (showMoreMenu) {
        ModalBottomSheet(
            onDismissRequest = { showMoreMenu = false },
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 20.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "Mais recursos",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                val moreScreens = listOf(
                    Screen.PRICE_COMPARE,
                    Screen.RECURRENCE,
                    Screen.WISHLIST,
                    Screen.HISTORY,
                    Screen.WIDGETS,
                    Screen.SETTINGS
                )
                moreScreens.forEach { screen ->
                    ListItem(
                        headlineContent = { Text(screen.title) },
                        supportingContent = {
                            Text(
                                when (screen) {
                                    Screen.PRICE_COMPARE -> "Compare preços registrados por produto e loja"
                                    Screen.RECURRENCE -> "Organize compras que se repetem"
                                    Screen.WISHLIST -> "Guarde produtos que pretende comprar"
                                    Screen.HISTORY -> "Consulte atividades e compras anteriores"
                                    Screen.WIDGETS -> "Veja atalhos e formatos de widgets"
                                    Screen.SETTINGS -> "Perfil e cópia de segurança dos dados"
                                    else -> ""
                                }
                            )
                        },
                        leadingContent = {
                            Icon(screen.selectedIcon, contentDescription = null)
                        },
                        modifier = Modifier.fillMaxWidth().clickable {
                            currentScreen = screen
                            showMoreMenu = false
                        },
                        colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surface)
                    )
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    // Trello-style Audit Timeline Modal
    auditDialogState?.let { pair ->
        AuditTimelineDialog(
            entityName = pair.second,
            logs = selectedAuditLogs,
            onDismiss = { viewModel.closeAudit() }
        )
    }
}
