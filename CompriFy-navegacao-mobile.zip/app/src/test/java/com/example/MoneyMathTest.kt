package com.example

import com.example.data.util.MoneyMath
import org.junit.Assert.assertEquals
import org.junit.Test

class MoneyMathTest {
    @Test
    fun multiply_roundsToCents() {
        assertEquals(3.33, MoneyMath.multiply(1.11, 3.0), 0.000001)
    }

    @Test
    fun sum_avoidsFloatingPointAccumulation() {
        assertEquals(0.30, MoneyMath.sum(listOf(0.10, 0.10, 0.10)), 0.000001)
    }
}
