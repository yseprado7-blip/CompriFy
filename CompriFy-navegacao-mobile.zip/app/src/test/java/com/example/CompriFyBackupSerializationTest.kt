package com.example

import com.example.data.backup.CompriFyBackup
import com.example.data.model.Profile
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class CompriFyBackupSerializationTest {
    @Test
    fun backupJson_roundTripsLocalProfile() {
        val adapter = Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()
            .adapter(CompriFyBackup::class.java)
        val backup = CompriFyBackup(
            profiles = listOf(
                Profile(
                    id = "local_user",
                    name = "Meu perfil",
                    email = "",
                    initials = "EU",
                    colorHex = "#2563EB",
                    role = "Administrador",
                    isCurrentUser = true
                )
            )
        )

        val restored = adapter.fromJson(adapter.toJson(backup))
        assertNotNull(restored)
        assertEquals("comprify-backup", restored?.format)
        assertEquals("Meu perfil", restored?.profiles?.single()?.name)
        assertEquals(true, restored?.profiles?.single()?.isCurrentUser)
    }
}
