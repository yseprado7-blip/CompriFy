package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.db.CompriFyDatabase
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun appName_isCompriFy() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("CompriFy", context.getString(R.string.app_name))
    }

    @Test
    fun newDatabase_startsWithOnlyLocalProfileAndNoDemoShoppingData() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.deleteDatabase("comprify_database.db")
        val db = CompriFyDatabase.getDatabase(context)
        val profiles = db.dao().getAllProfiles().first()
        val lists = db.dao().getAllShoppingLists().first()
        val products = db.dao().getAllProducts().first()

        assertEquals(1, profiles.size)
        assertNotNull(profiles.singleOrNull { it.id == "local_user" && it.isCurrentUser })
        assertTrue("A instalação não deve conter listas fictícias", lists.isEmpty())
        assertTrue("A instalação não deve conter produtos de demonstração", products.isEmpty())
        db.close()
    }
}
