package com.example.data.backup

import android.content.ContentResolver
import android.net.Uri
import androidx.room.withTransaction
import com.example.data.db.CompriFyDatabase
import com.example.data.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.io.IOException

data class CompriFyBackup(
    val format: String = "comprify-backup",
    val schemaVersion: Int = 1,
    val exportedAt: Long = System.currentTimeMillis(),
    val profiles: List<Profile> = emptyList(),
    val households: List<Household> = emptyList(),
    val shoppingLists: List<ShoppingList> = emptyList(),
    val shoppingListItems: List<ShoppingListItem> = emptyList(),
    val products: List<Product> = emptyList(),
    val budgets: List<Budget> = emptyList(),
    val purchases: List<Purchase> = emptyList(),
    val purchaseItems: List<PurchaseItem> = emptyList(),
    val productPrices: List<ProductPrice> = emptyList(),
    val recurrences: List<Recurrence> = emptyList(),
    val wishlistItems: List<WishlistItem> = emptyList(),
    val activityLogs: List<ActivityLog> = emptyList()
)

class CompriFyBackupService(
    private val database: CompriFyDatabase,
    private val contentResolver: ContentResolver
) {
    private val adapter = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()
        .adapter(CompriFyBackup::class.java)

    suspend fun export(uri: Uri) {
        val dao = database.dao()
        val snapshot = database.withTransaction {
            CompriFyBackup(
                profiles = dao.backupProfiles(),
                households = dao.backupHouseholds(),
                shoppingLists = dao.backupShoppingLists(),
                shoppingListItems = dao.backupShoppingListItems(),
                products = dao.backupProducts(),
                budgets = dao.backupBudgets(),
                purchases = dao.backupPurchases(),
                purchaseItems = dao.backupPurchaseItems(),
                productPrices = dao.backupProductPrices(),
                recurrences = dao.backupRecurrences(),
                wishlistItems = dao.backupWishlistItems(),
                activityLogs = dao.backupActivityLogs()
            )
        }
        val output = contentResolver.openOutputStream(uri)
            ?: throw IOException("Não foi possível criar o arquivo de backup.")
        output.bufferedWriter(Charsets.UTF_8).use { it.write(adapter.toJson(snapshot)) }
    }

    suspend fun import(uri: Uri) {
        val input = contentResolver.openInputStream(uri)
            ?: throw IOException("Não foi possível abrir o arquivo selecionado.")
        val json = input.bufferedReader(Charsets.UTF_8).use { reader ->
            val content = reader.readText()
            require(content.length <= 50 * 1024 * 1024) { "O arquivo de backup é maior que o limite permitido (50 MB)." }
            content
        }
        val backup = adapter.fromJson(json)
            ?: throw IOException("O arquivo não contém um backup válido do CompriFy.")
        require(backup.format == "comprify-backup") { "Este arquivo não é um backup do CompriFy." }
        require(backup.schemaVersion == 1) { "Versão de backup não compatível." }
        require(backup.profiles.size == 1 && backup.profiles.single().isCurrentUser && backup.households.size == 1) {
            "O backup não corresponde ao formato de perfil local do CompriFy."
        }
        require(backup.products.size <= 100_000 && backup.shoppingLists.size <= 100_000) {
            "O arquivo contém uma quantidade de dados inválida."
        }

        val dao = database.dao()
        database.withTransaction {
            dao.clearActivityLogs()
            dao.clearWishlistItems()
            dao.clearRecurrences()
            dao.clearProductPrices()
            dao.clearPurchaseItems()
            dao.clearPurchases()
            dao.clearShoppingListItems()
            dao.clearShoppingLists()
            dao.clearBudgets()
            dao.clearProducts()
            dao.clearHouseholds()
            dao.clearProfiles()

            dao.restoreProfiles(backup.profiles)
            dao.restoreHouseholds(backup.households)
            dao.restoreProducts(backup.products)
            dao.restoreBudgets(backup.budgets)
            dao.restoreShoppingLists(backup.shoppingLists)
            dao.restoreShoppingListItems(backup.shoppingListItems)
            dao.restorePurchases(backup.purchases)
            dao.restorePurchaseItems(backup.purchaseItems)
            dao.restoreProductPrices(backup.productPrices)
            dao.restoreRecurrences(backup.recurrences)
            dao.restoreWishlistItems(backup.wishlistItems)
            dao.restoreActivityLogs(backup.activityLogs)
        }
    }
}
