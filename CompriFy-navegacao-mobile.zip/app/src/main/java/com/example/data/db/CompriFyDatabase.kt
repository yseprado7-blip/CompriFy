package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.room.RoomDatabase.Callback
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.CompriFyDao
import com.example.data.model.*

@Database(
    entities = [
        Profile::class,
        Household::class,
        ShoppingList::class,
        ShoppingListItem::class,
        Product::class,
        Budget::class,
        Purchase::class,
        PurchaseItem::class,
        ProductPrice::class,
        Recurrence::class,
        WishlistItem::class,
        ActivityLog::class
    ],
    version = 3,
    exportSchema = true
)
abstract class CompriFyDatabase : RoomDatabase() {
    abstract fun dao(): CompriFyDao

    companion object {
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE shopping_list_items ADD COLUMN quantityInCart REAL NOT NULL DEFAULT 0.0")

                // Remove only the demo rows shipped in the recovered source. Keep any user-created
                // records, but convert their old participant attribution to this device's profile.
                db.execSQL("DELETE FROM shopping_list_items WHERE listId = 'list_mes_novembro' OR id IN ('item_1','item_2','item_3','item_4','item_5','item_6')")
                db.execSQL("DELETE FROM shopping_lists WHERE id = 'list_mes_novembro'")
                db.execSQL("DELETE FROM product_prices WHERE productId IN ('prod_arroz','prod_feijao','prod_leite','prod_azeite','prod_sabao','prod_detergente','prod_shampoo','prod_papel')")
                db.execSQL("DELETE FROM products WHERE id IN ('prod_arroz','prod_feijao','prod_leite','prod_azeite','prod_sabao','prod_detergente','prod_shampoo','prod_papel')")
                db.execSQL("DELETE FROM budgets WHERE id IN ('budget_main_nov','budget_extra')")
                db.execSQL("DELETE FROM recurrences WHERE id IN ('rec_leite','rec_sabao')")
                db.execSQL("DELETE FROM wishlist_items WHERE id IN ('wish_airfryer','wish_cafe')")
                db.execSQL("DELETE FROM activity_logs WHERE entityId IN ('list_mes_novembro','item_1','item_2','budget_main_nov')")

                db.execSQL("UPDATE shopping_lists SET ownerId = 'local_user', createdBy = 'Meu perfil', sharedMemberIds = ''")
                db.execSQL("UPDATE products SET createdBy = 'local_user'")
                db.execSQL("UPDATE budgets SET createdBy = 'Meu perfil'")
                db.execSQL("UPDATE shopping_list_items SET creatorId = 'local_user', creatorName = 'Meu perfil', creatorInitials = 'EU', collectedBy = NULL, collectedByName = NULL, quantityInCart = 0.0")
                db.execSQL("UPDATE purchases SET responsibleParticipantId = 'local_user', responsibleParticipantName = 'Meu perfil'")
                db.execSQL("UPDATE purchase_items SET registeredBy = 'Meu perfil'")
                db.execSQL("UPDATE product_prices SET registeredBy = 'Meu perfil'")
                db.execSQL("UPDATE recurrences SET createdBy = 'Meu perfil'")
                db.execSQL("UPDATE wishlist_items SET creatorId = 'local_user'")
                db.execSQL("UPDATE activity_logs SET actorId = 'local_user', actorName = 'Meu perfil', actorInitials = 'EU'")

                db.execSQL("DELETE FROM profiles")
                db.execSQL("DELETE FROM households")
                db.execSQL("INSERT INTO profiles (id, name, email, initials, colorHex, role, householdId, isCurrentUser) VALUES ('local_user', 'Meu perfil', '', 'EU', '#2563EB', 'Administrador', 'household_default', 1)")
                db.execSQL("INSERT INTO households (id, name, adminId, createdDate) VALUES ('household_default', 'Meu espaço', 'local_user', ${System.currentTimeMillis()})")
            }
        }

        @Volatile
        private var INSTANCE: CompriFyDatabase? = null

        fun getDatabase(context: Context): CompriFyDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    CompriFyDatabase::class.java,
                    "comprify_database.db"
                )
                    .addMigrations(MIGRATION_2_3)
                    // Never erase a user's database automatically. Future schema changes must
                    // provide explicit Room migrations.
                    .addCallback(LocalProfileCallback())
                    .build()
                    .also { INSTANCE = it }
            }
        }

        private class LocalProfileCallback : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                val now = System.currentTimeMillis()
                db.execSQL(
                    """INSERT OR IGNORE INTO profiles
                       (id, name, email, initials, colorHex, role, householdId, isCurrentUser)
                       VALUES ('local_user', 'Meu perfil', '', 'EU', '#2563EB', 'Administrador', 'household_default', 1)"""
                )
                db.execSQL(
                    """INSERT OR IGNORE INTO households (id, name, adminId, createdDate)
                       VALUES ('household_default', 'Meu espaço', 'local_user', $now)"""
                )
            }
        }
    }
}
