package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.db.CompriFyDatabase
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.util.UUID
import java.math.BigDecimal
import java.math.RoundingMode

class CompriFyRepository(private val database: CompriFyDatabase) {

    private val dao = database.dao()

    private fun money(value: Double): Double =
        BigDecimal.valueOf(value).setScale(2, RoundingMode.HALF_UP).toDouble()

    private fun moneyProduct(quantity: Double, unitPrice: Double): Double =
        BigDecimal.valueOf(quantity).multiply(BigDecimal.valueOf(unitPrice))
            .setScale(2, RoundingMode.HALF_UP).toDouble()

    // Single local profile for this installation.
    val currentProfile: Flow<Profile?> = dao.getCurrentProfile()

    suspend fun updateLocalProfileName(name: String) {
        require(name.isNotBlank()) { "Informe um nome válido." }
        val profile = dao.getCurrentProfile().firstOrNull() ?: return
        dao.updateProfile(profile.copy(name = name.trim(), initials = name.trim().split(Regex("\\s+")).take(2).mapNotNull { it.firstOrNull()?.uppercaseChar() }.joinToString("")))
    }

    // Shopping Lists
    val allLists: Flow<List<ShoppingList>> = dao.getAllShoppingLists()

    fun getListById(id: String): Flow<ShoppingList?> = dao.getShoppingListById(id)

    fun getItemsForList(listId: String): Flow<List<ShoppingListItem>> = dao.getItemsForList(listId)

    suspend fun createShoppingList(
        name: String,
        description: String,
        type: String,
        budgetId: String?
    ): String {
        require(name.isNotBlank()) { "Informe um nome para a lista." }
        val current = dao.getCurrentProfile().firstOrNull()
        val listId = UUID.randomUUID().toString()
        val list = ShoppingList(
            id = listId,
            ownerId = current?.id ?: "local_user",
            name = name,
            description = description,
            type = type,
            status = "Planejada",
            budgetId = budgetId,
            sharedMemberIds = "",
            createdBy = current?.name ?: "Meu perfil"
        )
        dao.insertShoppingList(list)
        dao.insertLog(
            ActivityLog(
                entityType = "Lista",
                entityId = listId,
                actionType = "Criação",
                actorId = current?.id ?: "local_user",
                actorName = current?.name ?: "Meu perfil",
                actorInitials = current?.initials ?: "EU",
                description = "${current?.name ?: "Meu perfil"} criou a lista '$name' ($type)"
            )
        )
        return listId
    }

    suspend fun updateListStatus(listId: String, status: String) {
        val list = dao.getShoppingListByIdOnce(listId) ?: return
        val current = dao.getCurrentProfile().firstOrNull()
        dao.updateShoppingList(list.copy(status = status, updatedDate = System.currentTimeMillis()))
        dao.insertLog(
            ActivityLog(
                entityType = "Lista",
                entityId = listId,
                actionType = "Alteração de Status",
                actorId = current?.id ?: "local_user",
                actorName = current?.name ?: "Meu perfil",
                actorInitials = current?.initials ?: "EU",
                description = "Status da lista '${list.name}' alterado para '$status'"
            )
        )
    }

    suspend fun deleteShoppingList(listId: String) {
        val list = dao.getShoppingListByIdOnce(listId) ?: return
        val current = dao.getCurrentProfile().firstOrNull()
        dao.deleteItemsByListId(listId)
        dao.deleteShoppingList(listId)
        dao.insertLog(
            ActivityLog(
                entityType = "Lista",
                entityId = listId,
                actionType = "Exclusão",
                actorId = current?.id ?: "local_user",
                actorName = current?.name ?: "Meu perfil",
                actorInitials = current?.initials ?: "EU",
                description = "${current?.name ?: "Meu perfil"} excluiu a lista '${list.name}'"
            )
        )
    }

    // List Items with Duplicate Handling
    suspend fun checkDuplicateItem(listId: String, name: String, productId: String): ShoppingListItem? {
        return dao.findExistingItemInList(listId, name, productId)
    }

    suspend fun addItemToList(
        listId: String,
        productId: String,
        productName: String,
        category: String,
        brand: String,
        quantity: Double,
        unit: String,
        estimatedPrice: Double,
        priority: String,
        imageUrl: String = "",
        iconEmoji: String = "📦",
        aisle: String = "Geral"
    ) {
        require(productName.isNotBlank() && category.isNotBlank()) { "Informe o nome e a categoria do produto." }
        require(quantity > 0.0 && estimatedPrice >= 0.0) { "Quantidade e preço estimado precisam ser válidos." }
        val current = dao.getCurrentProfile().firstOrNull()
        val item = ShoppingListItem(
            listId = listId,
            productId = productId,
            productName = productName,
            category = category,
            brand = brand,
            quantityPlanned = quantity,
            quantityPurchased = 0.0,
            quantityPending = quantity,
            unit = unit,
            estimatedPrice = estimatedPrice,
            realPrice = estimatedPrice,
            priority = priority,
            status = "Pendente",
            imageUrl = imageUrl,
            iconEmoji = iconEmoji,
            aisle = aisle,
            creatorId = current?.id ?: "local_user",
            creatorName = current?.name ?: "Meu perfil",
            creatorInitials = current?.initials ?: "EU"
        )
        dao.insertListItem(item)
        dao.insertLog(
            ActivityLog(
                entityType = "Produto",
                entityId = item.id,
                actionType = "Inclusão em Lista",
                actorId = current?.id ?: "local_user",
                actorName = current?.name ?: "Meu perfil",
                actorInitials = current?.initials ?: "EU",
                description = "${current?.name ?: "Meu perfil"} adicionou '$productName' ($quantity $unit) na lista"
            )
        )
    }

    suspend fun updateListItemQuantity(itemId: String, delta: Double) {
        val item = dao.getItemById(itemId) ?: return
        val newPlanned = (item.quantityPlanned + delta).coerceAtLeast(maxOf(1.0, item.quantityPurchased))
        val newPending = (newPlanned - item.quantityPurchased).coerceAtLeast(0.0)
        val newInCart = item.quantityInCart.coerceAtMost(newPending)
        val newStatus = when {
            newInCart > 0.0 -> "No Carrinho"
            newPending <= 0.0 -> "Comprado"
            else -> "Pendente"
        }
        val current = dao.getCurrentProfile().firstOrNull()
        dao.updateListItem(item.copy(
            quantityPlanned = newPlanned,
            quantityPending = newPending,
            quantityInCart = newInCart,
            status = newStatus,
            updatedDate = System.currentTimeMillis()
        ))
        dao.insertLog(
            ActivityLog(
                entityType = "Produto",
                entityId = itemId,
                actionType = "Alteração de Quantidade",
                actorId = current?.id ?: "local_user",
                actorName = current?.name ?: "Meu perfil",
                actorInitials = current?.initials ?: "EU",
                description = "Quantidade de '${item.productName}' alterada para $newPlanned ${item.unit}"
            )
        )
    }

    suspend fun updateItemInCart(
        itemId: String,
        collectedQuantity: Double,
        realPrice: Double,
        inCart: Boolean
    ) {
        val item = dao.getItemById(itemId) ?: return
        if (inCart) require(collectedQuantity > 0.0 && realPrice >= 0.0) { "Informe uma quantidade e um preço válidos." }
        val current = dao.getCurrentProfile().firstOrNull()
        val safeCollectedQuantity = if (inCart) collectedQuantity.coerceIn(0.0, item.quantityPending) else 0.0
        val newStatus = if (safeCollectedQuantity > 0.0) "No Carrinho" else "Pendente"
        val updated = item.copy(
            quantityInCart = safeCollectedQuantity,
            realPrice = if (inCart) money(realPrice) else item.realPrice,
            status = newStatus,
            collectedBy = if (inCart) current?.id else null,
            collectedByName = if (inCart) current?.name else null,
            updatedDate = System.currentTimeMillis()
        )
        dao.updateListItem(updated)
        dao.insertLog(
            ActivityLog(
                entityType = "Produto",
                entityId = itemId,
                actionType = if (inCart) "Coletado" else "Removido do Carrinho",
                actorId = current?.id ?: "local_user",
                actorName = current?.name ?: "Meu perfil",
                actorInitials = current?.initials ?: "EU",
                description = "${current?.name ?: "Meu perfil"} ${if (inCart) "coletou" else "devolveu"} '${item.productName}' ($safeCollectedQuantity ${item.unit} a R$ %.2f)".format(money(realPrice))
            )
        )
    }

    suspend fun deleteListItem(itemId: String) {
        val item = dao.getItemById(itemId) ?: return
        val current = dao.getCurrentProfile().firstOrNull()
        dao.deleteListItem(itemId)
        dao.insertLog(
            ActivityLog(
                entityType = "Produto",
                entityId = itemId,
                actionType = "Remoção",
                actorId = current?.id ?: "local_user",
                actorName = current?.name ?: "Meu perfil",
                actorInitials = current?.initials ?: "EU",
                description = "${current?.name ?: "Meu perfil"} removeu '${item.productName}' da lista"
            )
        )
    }

    // Checkout & Purchase Execution (Preserves history & reconciles planned vs actual)
    suspend fun finalizePurchase(
        listId: String?,
        budgetId: String?,
        storeName: String,
        itemsSubtotal: Double,
        discountTotal: Double,
        finalAmount: Double,
        cashierReportedAmount: Double,
        paymentMethod: String,
        installments: Int,
        notes: String,
        purchasedItemsData: List<CheckoutItemData>
    ): String = database.withTransaction {
        require(storeName.isNotBlank()) { "Informe a loja da compra." }
        require(purchasedItemsData.isNotEmpty()) { "Adicione pelo menos um item à compra." }
        require(installments >= 1) { "A quantidade de parcelas deve ser maior que zero." }
        require(finalAmount >= 0.0 && itemsSubtotal >= 0.0 && discountTotal >= 0.0) {
            "Os valores da compra não podem ser negativos."
        }

        val current = dao.getCurrentProfile().firstOrNull()
        val purchaseId = UUID.randomUUID().toString()
        val list = listId?.let { dao.getShoppingListByIdOnce(it) }
        val normalizedTotal = money(finalAmount)

        val purchase = Purchase(
            id = purchaseId,
            listId = listId,
            listName = list?.name ?: "Compra Avulsa",
            budgetId = budgetId,
            storeName = storeName.trim(),
            responsibleParticipantId = current?.id ?: "local_user",
            responsibleParticipantName = current?.name ?: "Meu perfil",
            purchaseDate = System.currentTimeMillis(),
            itemsSubtotal = money(itemsSubtotal),
            discountTotal = money(discountTotal),
            finalAmount = normalizedTotal,
            cashierReportedAmount = money(cashierReportedAmount),
            paymentMethod = paymentMethod,
            installments = installments,
            installmentValue = money(normalizedTotal / installments),
            status = "Finalizada",
            notes = notes
        )
        dao.insertPurchase(purchase)

        val purchaseItemsList = mutableListOf<PurchaseItem>()
        for (pItem in purchasedItemsData) {
            require(pItem.quantity > 0.0 && pItem.unitPrice >= 0.0) {
                "Quantidade ou preço inválido no item '${pItem.productName}'."
            }
            val itemSubtotal = moneyProduct(pItem.quantity, pItem.unitPrice)
            purchaseItemsList.add(
                PurchaseItem(
                    purchaseId = purchaseId,
                    listItemId = pItem.listItemId,
                    productId = pItem.productId,
                    productName = pItem.productName,
                    quantity = pItem.quantity,
                    unitPrice = money(pItem.unitPrice),
                    subtotal = itemSubtotal,
                    discount = 0.0,
                    finalSubtotal = itemSubtotal,
                    storeName = storeName.trim(),
                    registeredBy = current?.name ?: "Meu perfil"
                )
            )

            dao.insertPrice(
                ProductPrice(
                    productId = pItem.productId,
                    productName = pItem.productName,
                    storeName = storeName.trim(),
                    price = money(pItem.unitPrice),
                    unit = pItem.unit,
                    pricePerUnit = money(pItem.unitPrice),
                    source = "Compra Efetiva",
                    registeredBy = current?.name ?: "Meu perfil"
                )
            )

            if (pItem.listItemId != null) {
                val original = dao.getItemById(pItem.listItemId)
                if (original != null) {
                    require(pItem.quantity <= original.quantityPending) {
                        "A quantidade comprada de '${pItem.productName}' excede o que ainda estava pendente."
                    }
                    val newPurchased = original.quantityPurchased + pItem.quantity
                    val newPending = (original.quantityPlanned - newPurchased).coerceAtLeast(0.0)
                    dao.updateListItem(
                        original.copy(
                            quantityPurchased = newPurchased,
                            quantityPending = newPending,
                            quantityInCart = 0.0,
                            status = if (newPending <= 0.0) "Comprado" else "Pendente",
                            realPrice = money(pItem.unitPrice),
                            updatedDate = System.currentTimeMillis()
                        )
                    )
                }
            }
        }
        dao.insertPurchaseItems(purchaseItemsList)

        if (listId != null) {
            val remainingItems = dao.getItemsForListOnce(listId)
            val allDone = remainingItems.isNotEmpty() && remainingItems.all { it.quantityPending <= 0.0 }
            updateListStatus(listId, if (allDone) "Concluída" else "Parcialmente concluída")
        }

        dao.insertLog(
            ActivityLog(
                entityType = "Compra",
                entityId = purchaseId,
                actionType = "Finalização de Compra",
                actorId = current?.id ?: "local_user",
                actorName = current?.name ?: "Meu perfil",
                actorInitials = current?.initials ?: "EU",
                description = "${current?.name ?: "Meu perfil"} finalizou compra no '$storeName' (Total: R$ %.2f via $paymentMethod)".format(normalizedTotal)
            )
        )

        purchaseId
    }

    // Catalog Products
    val allProducts: Flow<List<Product>> = dao.getAllProducts()

    suspend fun createProduct(
        name: String,
        category: String,
        brand: String,
        unit: String,
        imageUrl: String = "",
        iconEmoji: String = "📦",
        aisle: String = "Geral"
    ): String {
        val current = dao.getCurrentProfile().firstOrNull()
        val prod = Product(
            name = name,
            category = category,
            brand = brand,
            defaultUnit = unit,
            imageUrl = imageUrl,
            iconEmoji = iconEmoji,
            aisle = aisle,
            createdBy = current?.id ?: "local_user"
        )
        dao.insertProduct(prod)
        dao.insertLog(
            ActivityLog(
                entityType = "Catálogo",
                entityId = prod.id,
                actionType = "Criação",
                actorId = current?.id ?: "local_user",
                actorName = current?.name ?: "Meu perfil",
                actorInitials = current?.initials ?: "EU",
                description = "Novo produto cadastrado no catálogo: '$name' ($category)"
            )
        )
        return prod.id
    }

    // Budgets
    val allBudgets: Flow<List<Budget>> = dao.getAllBudgets()

    suspend fun createBudget(name: String, type: String, totalAmount: Double, alertThreshold: Int) {
        require(name.isNotBlank() && totalAmount > 0.0 && alertThreshold in 1..100) { "Confira o nome, o valor e o percentual de alerta do orçamento." }
        val current = dao.getCurrentProfile().firstOrNull()
        val budget = Budget(
            name = name,
            type = type,
            totalAmount = totalAmount,
            alertThresholdPercent = alertThreshold,
            createdBy = current?.name ?: "Meu perfil"
        )
        dao.insertBudget(budget)
        dao.insertLog(
            ActivityLog(
                entityType = "Orçamento",
                entityId = budget.id,
                actionType = "Criação",
                actorId = current?.id ?: "local_user",
                actorName = current?.name ?: "Meu perfil",
                actorInitials = current?.initials ?: "EU",
                description = "Orçamento '$name' criado com teto de R$ %.2f".format(totalAmount)
            )
        )
    }

    // Purchases
    val allPurchases: Flow<List<Purchase>> = dao.getAllPurchases()

    fun getPurchaseItems(purchaseId: String): Flow<List<PurchaseItem>> = dao.getItemsForPurchase(purchaseId)

    // Prices
    val allPrices: Flow<List<ProductPrice>> = dao.getAllPrices()

    suspend fun addPrice(productId: String, productName: String, storeName: String, price: Double, unit: String) {
        require(productName.isNotBlank() && storeName.isNotBlank() && price >= 0.0) { "Informe produto, loja e preço válidos." }
        val current = dao.getCurrentProfile().firstOrNull()
        val p = ProductPrice(
            productId = productId,
            productName = productName,
            storeName = storeName,
            price = price,
            unit = unit,
            pricePerUnit = price,
            source = "Manual",
            registeredBy = current?.name ?: "Meu perfil"
        )
        dao.insertPrice(p)
    }

    // Recurrences
    val allRecurrences: Flow<List<Recurrence>> = dao.getAllRecurrences()

    suspend fun createRecurrence(
        productName: String,
        category: String,
        intervalDays: Int,
        intervalLabel: String,
        quantity: Double,
        unit: String,
        store: String,
        refPrice: Double
    ) {
        val current = dao.getCurrentProfile().firstOrNull()
        val rec = Recurrence(
            productName = productName,
            category = category,
            intervalDays = intervalDays,
            intervalLabel = intervalLabel,
            nextDate = System.currentTimeMillis() + (intervalDays * 24 * 60 * 60 * 1000L),
            quantity = quantity,
            unit = unit,
            habitualStore = store,
            referencePrice = refPrice,
            createdBy = current?.name ?: "Meu perfil"
        )
        dao.insertRecurrence(rec)
        dao.insertLog(
            ActivityLog(
                entityType = "Recorrência",
                entityId = rec.id,
                actionType = "Criação",
                actorId = current?.id ?: "local_user",
                actorName = current?.name ?: "Meu perfil",
                actorInitials = current?.initials ?: "EU",
                description = "Nova recorrência agendada: '$productName' ($intervalLabel)"
            )
        )
    }

    suspend fun postponeRecurrence(id: String, days: Int) {
        val all = dao.getAllRecurrences().firstOrNull() ?: return
        val item = all.find { it.id == id } ?: return
        val updated = item.copy(nextDate = item.nextDate + (days * 24 * 60 * 60 * 1000L))
        dao.updateRecurrence(updated)
    }

    // Wishlist
    val allWishlist: Flow<List<WishlistItem>> = dao.getAllWishlist()

    suspend fun addWishlistItem(name: String, category: String, targetPrice: Double, priority: String, notes: String) {
        val current = dao.getCurrentProfile().firstOrNull()
        val item = WishlistItem(
            productName = name,
            category = category,
            targetPrice = targetPrice,
            priority = priority,
            notes = notes,
            creatorId = current?.name ?: "Meu perfil"
        )
        dao.insertWishlistItem(item)
    }

    suspend fun deleteWishlistItem(id: String) {
        dao.deleteWishlistItem(id)
    }

    // Activity Logs
    val allLogs: Flow<List<ActivityLog>> = dao.getAllLogs()

    fun getLogsForEntity(entityId: String): Flow<List<ActivityLog>> = dao.getLogsForEntity(entityId)
}

data class CheckoutItemData(
    val listItemId: String?,
    val productId: String,
    val productName: String,
    val quantity: Double,
    val unitPrice: Double,
    val unit: String
)
