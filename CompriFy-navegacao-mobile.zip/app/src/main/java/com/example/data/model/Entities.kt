package com.example.data.model

import androidx.room.Entity
import androidx.room.ColumnInfo
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "profiles")
data class Profile(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val email: String,
    val initials: String,
    val colorHex: String,
    val role: String = "Editor", // "Administrador", "Editor", "Visualizador"
    val householdId: String = "household_default",
    val isCurrentUser: Boolean = false
)

@Entity(tableName = "households")
data class Household(
    @PrimaryKey val id: String = "household_default",
    val name: String = "Meu espaço",
    val adminId: String,
    val createdDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "shopping_lists")
data class ShoppingList(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val householdId: String = "household_default",
    val ownerId: String,
    val name: String,
    val description: String = "",
    val type: String = "Mensal", // "Mensal", "Semanal", "Por finalidade", "Por loja", "Personalizado", "Favorita", "Modelo"
    val status: String = "Planejada", // "Planejada", "Comprando", "Em conferência", "Concluída", "Cancelada"
    val budgetId: String? = null,
    val plannedDate: Long = System.currentTimeMillis(),
    val notes: String = "",
    val sharedMemberIds: String = "", // Comma-separated profile IDs
    val createdDate: Long = System.currentTimeMillis(),
    val updatedDate: Long = System.currentTimeMillis(),
    val createdBy: String
)

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val householdId: String = "household_default",
    val name: String,
    val category: String, // "Alimentação", "Limpeza", "Higiene", "Higiene Pessoal", "Bebidas", "Outros"
    val subcategory: String = "",
    val brand: String = "",
    val defaultUnit: String = "un", // "un", "kg", "g", "L", "ml", "pct", "cx"
    val packageSize: String = "1",
    val barcode: String = "",
    val notes: String = "",
    val imageUrl: String = "",
    val iconEmoji: String = "📦",
    val aisle: String = "Geral",
    val createdBy: String,
    val createdDate: Long = System.currentTimeMillis(),
    val active: Boolean = true
)

@Entity(tableName = "shopping_list_items")
data class ShoppingListItem(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val listId: String,
    val productId: String,
    val productName: String,
    val category: String,
    val brand: String = "",
    val quantityPlanned: Double = 1.0,
    val quantityPurchased: Double = 0.0,
    val quantityPending: Double = 1.0,
    @ColumnInfo(defaultValue = "0.0") val quantityInCart: Double = 0.0,
    val unit: String = "un",
    val estimatedPrice: Double = 0.0,
    val realPrice: Double = 0.0,
    val priority: String = "Média", // "Alta", "Média", "Baixa"
    val status: String = "Pendente", // "Pendente", "No Carrinho", "Comprado"
    val notes: String = "",
    val imageUrl: String = "",
    val iconEmoji: String = "📦",
    val aisle: String = "Geral",
    val creatorId: String,
    val creatorName: String,
    val creatorInitials: String,
    val collectedBy: String? = null,
    val collectedByName: String? = null,
    val createdDate: Long = System.currentTimeMillis(),
    val updatedDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "budgets")
data class Budget(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val householdId: String = "household_default",
    val name: String,
    val type: String = "Principal", // "Principal", "Extraordinário", "Recorrente", "Específico"
    val totalAmount: Double,
    val alertThresholdPercent: Int = 80, // Limite de alerta (ex: 80%)
    val periodMonth: String = "Não definido",
    val createdBy: String,
    val createdDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "purchases")
data class Purchase(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val householdId: String = "household_default",
    val listId: String? = null,
    val listName: String = "",
    val budgetId: String? = null,
    val storeName: String,
    val responsibleParticipantId: String,
    val responsibleParticipantName: String,
    val purchaseDate: Long = System.currentTimeMillis(),
    val itemsSubtotal: Double,
    val discountTotal: Double = 0.0,
    val finalAmount: Double,
    val cashierReportedAmount: Double = 0.0,
    val paymentMethod: String = "Crédito", // "Pix", "Dinheiro", "Crédito", "Débito", "Boleto", "Outro"
    val installments: Int = 1,
    val installmentValue: Double = 0.0,
    val status: String = "Finalizada", // "Finalizada", "Cancelada", "Parcialmente devolvida", "Devolvida"
    val notes: String = "",
    val createdDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "purchase_items")
data class PurchaseItem(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val purchaseId: String,
    val listItemId: String? = null,
    val productId: String,
    val productName: String,
    val quantity: Double,
    val unitPrice: Double,
    val subtotal: Double,
    val discount: Double = 0.0,
    val finalSubtotal: Double,
    val storeName: String,
    val registeredBy: String,
    val createdDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "product_prices")
data class ProductPrice(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val productId: String,
    val productName: String,
    val storeName: String,
    val price: Double,
    val unit: String,
    val pricePerUnit: Double,
    val source: String = "Manual", // "Manual", "Compra Efetiva"
    val registeredBy: String,
    val date: Long = System.currentTimeMillis()
)

@Entity(tableName = "recurrences")
data class Recurrence(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val householdId: String = "household_default",
    val productName: String,
    val category: String,
    val intervalDays: Int = 7,
    val intervalLabel: String = "Semanal", // "Semanal", "Quinzenal", "Mensal", "Personalizado"
    val nextDate: Long,
    val quantity: Double = 1.0,
    val unit: String = "un",
    val habitualStore: String = "",
    val referencePrice: Double = 0.0,
    val budgetId: String? = null,
    val status: String = "Ativo", // "Ativo", "Pausado", "Concluído"
    val createdBy: String,
    val createdDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "wishlist_items")
data class WishlistItem(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val productName: String,
    val category: String = "Geral",
    val targetPrice: Double = 0.0,
    val priority: String = "Média prioridade", // "Alta prioridade", "Média prioridade", "Baixa prioridade", "Aguardando promoção", "Compra futura"
    val notes: String = "",
    val creatorId: String,
    val createdDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "activity_logs")
data class ActivityLog(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val householdId: String = "household_default",
    val entityType: String, // "Lista", "Produto", "Compra", "Orçamento", "Recorrência", "Desejo"
    val entityId: String,
    val actionType: String, // "Criação", "Edição", "Coletado", "Compra Realizada", "Remoção", "Desconto Aplicado", "Devolução"
    val actorId: String,
    val actorName: String,
    val actorInitials: String,
    val description: String,
    val previousValue: String? = null,
    val newValue: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
