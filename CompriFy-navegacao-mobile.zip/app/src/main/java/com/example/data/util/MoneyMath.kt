package com.example.data.util

import java.math.BigDecimal
import java.math.RoundingMode

/** Currency calculations are rounded to cents at the point each amount is produced. */
object MoneyMath {
    fun round(value: Double): Double =
        BigDecimal.valueOf(value).setScale(2, RoundingMode.HALF_UP).toDouble()

    fun multiply(unitPrice: Double, quantity: Double): Double =
        BigDecimal.valueOf(unitPrice).multiply(BigDecimal.valueOf(quantity))
            .setScale(2, RoundingMode.HALF_UP).toDouble()

    fun sum(values: Iterable<Double>): Double =
        values.fold(BigDecimal.ZERO) { total, value -> total.add(BigDecimal.valueOf(value)) }
            .setScale(2, RoundingMode.HALF_UP).toDouble()

    fun subtract(left: Double, right: Double): Double =
        BigDecimal.valueOf(left).subtract(BigDecimal.valueOf(right))
            .setScale(2, RoundingMode.HALF_UP).toDouble()
}
