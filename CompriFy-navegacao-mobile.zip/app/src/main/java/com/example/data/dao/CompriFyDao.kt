package com.example.data.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CompriFyDao {

    // Profiles
    @Query("SELECT * FROM profiles ORDER BY name ASC")
    fun getAllProfiles(): Flow<List<Profile>>

    @Query("SELECT * FROM profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileById(id: String): Profile?

    @Query("SELECT * FROM profiles WHERE isCurrentUser = 1 LIMIT 1")
    fun getCurrentProfile(): Flow<Profile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: Profile)

    @Update
    suspend fun updateProfile(profile: Profile)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfiles(profiles: List<Profile>)

    // Households
    @Query("SELECT * FROM households LIMIT 1")
    fun getHousehold(): Flow<Household?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHousehold(household: Household)

    // Shopping Lists
    @Query("SELECT * FROM shopping_lists ORDER BY createdDate DESC")
    fun getAllShoppingLists(): Flow<List<ShoppingList>>

    @Query("SELECT * FROM shopping_lists WHERE id = :id LIMIT 1")
    fun getShoppingListById(id: String): Flow<ShoppingList?>

    @Query("SELECT * FROM shopping_lists WHERE id = :id LIMIT 1")
    suspend fun getShoppingListByIdOnce(id: String): ShoppingList?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShoppingList(list: ShoppingList)

    @Update
    suspend fun updateShoppingList(list: ShoppingList)

    @Query("DELETE FROM shopping_lists WHERE id = :id")
    suspend fun deleteShoppingList(id: String)

    // Shopping List Items
    @Query("SELECT * FROM shopping_list_items WHERE listId = :listId ORDER BY createdDate ASC")
    fun getItemsForList(listId: String): Flow<List<ShoppingListItem>>

    @Query("SELECT * FROM shopping_list_items WHERE listId = :listId ORDER BY createdDate ASC")
    suspend fun getItemsForListOnce(listId: String): List<ShoppingListItem>

    @Query("SELECT * FROM shopping_list_items WHERE id = :id LIMIT 1")
    suspend fun getItemById(id: String): ShoppingListItem?

    @Query("SELECT * FROM shopping_list_items WHERE listId = :listId AND (productName = :name OR productId = :productId) LIMIT 1")
    suspend fun findExistingItemInList(listId: String, name: String, productId: String): ShoppingListItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertListItem(item: ShoppingListItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertListItems(items: List<ShoppingListItem>)

    @Update
    suspend fun updateListItem(item: ShoppingListItem)

    @Query("DELETE FROM shopping_list_items WHERE id = :id")
    suspend fun deleteListItem(id: String)

    @Query("DELETE FROM shopping_list_items WHERE listId = :listId")
    suspend fun deleteItemsByListId(listId: String)

    // Products Catalog
    @Query("SELECT * FROM products WHERE active = 1 ORDER BY name ASC")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE name LIKE '%' || :query || '%' AND active = 1")
    fun searchProducts(query: String): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE name = :name LIMIT 1")
    suspend fun findProductByName(name: String): Product?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<Product>)

    @Update
    suspend fun updateProduct(product: Product)

    @Query("UPDATE products SET active = 0 WHERE id = :id")
    suspend fun softDeleteProduct(id: String)

    // Budgets
    @Query("SELECT * FROM budgets ORDER BY createdDate DESC")
    fun getAllBudgets(): Flow<List<Budget>>

    @Query("SELECT * FROM budgets WHERE id = :id LIMIT 1")
    suspend fun getBudgetById(id: String): Budget?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBudget(budget: Budget)

    @Update
    suspend fun updateBudget(budget: Budget)

    @Query("DELETE FROM budgets WHERE id = :id")
    suspend fun deleteBudget(id: String)

    // Purchases
    @Query("SELECT * FROM purchases ORDER BY purchaseDate DESC")
    fun getAllPurchases(): Flow<List<Purchase>>

    @Query("SELECT * FROM purchases WHERE id = :id LIMIT 1")
    fun getPurchaseById(id: String): Flow<Purchase?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchase(purchase: Purchase)

    @Update
    suspend fun updatePurchase(purchase: Purchase)

    // Purchase Items
    @Query("SELECT * FROM purchase_items WHERE purchaseId = :purchaseId ORDER BY createdDate ASC")
    fun getItemsForPurchase(purchaseId: String): Flow<List<PurchaseItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchaseItems(items: List<PurchaseItem>)

    // Product Prices
    @Query("SELECT * FROM product_prices ORDER BY date DESC")
    fun getAllPrices(): Flow<List<ProductPrice>>

    @Query("SELECT * FROM product_prices WHERE productId = :productId OR productName = :productName ORDER BY price ASC")
    fun getPricesForProduct(productId: String, productName: String): Flow<List<ProductPrice>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrice(price: ProductPrice)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrices(prices: List<ProductPrice>)

    // Recurrences
    @Query("SELECT * FROM recurrences ORDER BY nextDate ASC")
    fun getAllRecurrences(): Flow<List<Recurrence>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecurrence(recurrence: Recurrence)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecurrences(recurrences: List<Recurrence>)

    @Update
    suspend fun updateRecurrence(recurrence: Recurrence)

    @Query("DELETE FROM recurrences WHERE id = :id")
    suspend fun deleteRecurrence(id: String)

    // Wishlist
    @Query("SELECT * FROM wishlist_items ORDER BY createdDate DESC")
    fun getAllWishlist(): Flow<List<WishlistItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWishlistItem(item: WishlistItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWishlistItems(items: List<WishlistItem>)

    @Query("DELETE FROM wishlist_items WHERE id = :id")
    suspend fun deleteWishlistItem(id: String)

    // Activity Logs
    @Query("SELECT * FROM activity_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<ActivityLog>>

    @Query("SELECT * FROM activity_logs WHERE entityId = :entityId ORDER BY timestamp DESC")
    fun getLogsForEntity(entityId: String): Flow<List<ActivityLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ActivityLog)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLogs(logs: List<ActivityLog>)

    // Backup/restore support. All reads and writes are performed inside a Room transaction.
    @Query("SELECT * FROM profiles") suspend fun backupProfiles(): List<Profile>
    @Query("SELECT * FROM households") suspend fun backupHouseholds(): List<Household>
    @Query("SELECT * FROM shopping_lists") suspend fun backupShoppingLists(): List<ShoppingList>
    @Query("SELECT * FROM shopping_list_items") suspend fun backupShoppingListItems(): List<ShoppingListItem>
    @Query("SELECT * FROM products") suspend fun backupProducts(): List<Product>
    @Query("SELECT * FROM budgets") suspend fun backupBudgets(): List<Budget>
    @Query("SELECT * FROM purchases") suspend fun backupPurchases(): List<Purchase>
    @Query("SELECT * FROM purchase_items") suspend fun backupPurchaseItems(): List<PurchaseItem>
    @Query("SELECT * FROM product_prices") suspend fun backupProductPrices(): List<ProductPrice>
    @Query("SELECT * FROM recurrences") suspend fun backupRecurrences(): List<Recurrence>
    @Query("SELECT * FROM wishlist_items") suspend fun backupWishlistItems(): List<WishlistItem>
    @Query("SELECT * FROM activity_logs") suspend fun backupActivityLogs(): List<ActivityLog>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restoreProfiles(items: List<Profile>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restoreHouseholds(items: List<Household>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restoreShoppingLists(items: List<ShoppingList>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restoreShoppingListItems(items: List<ShoppingListItem>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restoreProducts(items: List<Product>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restoreBudgets(items: List<Budget>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restorePurchases(items: List<Purchase>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restorePurchaseItems(items: List<PurchaseItem>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restoreProductPrices(items: List<ProductPrice>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restoreRecurrences(items: List<Recurrence>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restoreWishlistItems(items: List<WishlistItem>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restoreActivityLogs(items: List<ActivityLog>)

    @Query("DELETE FROM activity_logs") suspend fun clearActivityLogs()
    @Query("DELETE FROM wishlist_items") suspend fun clearWishlistItems()
    @Query("DELETE FROM recurrences") suspend fun clearRecurrences()
    @Query("DELETE FROM product_prices") suspend fun clearProductPrices()
    @Query("DELETE FROM purchase_items") suspend fun clearPurchaseItems()
    @Query("DELETE FROM purchases") suspend fun clearPurchases()
    @Query("DELETE FROM shopping_list_items") suspend fun clearShoppingListItems()
    @Query("DELETE FROM shopping_lists") suspend fun clearShoppingLists()
    @Query("DELETE FROM budgets") suspend fun clearBudgets()
    @Query("DELETE FROM products") suspend fun clearProducts()
    @Query("DELETE FROM households") suspend fun clearHouseholds()
    @Query("DELETE FROM profiles") suspend fun clearProfiles()

}
