package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Profile
import com.example.data.model.ShoppingList
import com.example.data.model.ShoppingListItem
import com.example.data.repository.CheckoutItemData
import com.example.data.util.MoneyMath
import com.example.ui.components.ParticipantAvatar
import com.example.ui.components.ProductThumbnail
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingModeScreen(
    list: ShoppingList?,
    items: List<ShoppingListItem>,
    currentProfile: Profile?,
    onUpdateCartItem: (itemId: String, collectedQty: Double, realPrice: Double, inCart: Boolean) -> Unit,
    onFinalizeCheckout: (
        storeName: String,
        itemsSubtotal: Double,
        discountTotal: Double,
        finalAmount: Double,
        cashierReportedAmount: Double,
        paymentMethod: String,
        installments: Int,
        notes: String,
        purchasedItems: List<CheckoutItemData>
    ) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedItemForCollection by remember { mutableStateOf<ShoppingListItem?>(null) }
    var showCheckoutModal by remember { mutableStateOf(false) }

    val collectedItems = items.filter { it.status == "No Carrinho" }
    val pendingItems = items.filter { it.status != "No Carrinho" && it.status != "Comprado" }

    val totalCollectedAmount = MoneyMath.sum(collectedItems.map { MoneyMath.multiply(if (it.realPrice > 0) it.realPrice else it.estimatedPrice, it.quantityInCart) })
    val totalCount = items.size
    val collectedCount = collectedItems.size
    val progress = if (totalCount > 0) collectedCount.toFloat() / totalCount else 0f

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Modo Comprando",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = list?.name ?: "Carrinho Digital",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Voltar")
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Text(
                            text = "$collectedCount de $totalCount coletados",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            // Live Cart Sticky Bar & "Ir para o Caixa" CTA
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Total Parcial no Carrinho",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "R$ %.2f".format(totalCollectedAmount),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Button(
                            onClick = { showCheckoutModal = true },
                            enabled = collectedItems.isNotEmpty(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
                        ) {
                            Icon(Icons.Default.PointOfSale, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Ir para o Caixa", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 10.dp, bottom = 20.dp)
        ) {
            // Progress Bar
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = BlueSurface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Progresso da Coleta",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = NavyPrimary
                            )
                            Text(
                                text = "${(progress * 100).toInt()}% concluído",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = BlueVibrant
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = SuccessGreen,
                            trackColor = Color.White
                        )
                    }
                }
            }

            // In-Cart (Coletados) Section
            if (collectedItems.isNotEmpty()) {
                item {
                    Text(
                        text = "No Carrinho (${collectedItems.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SuccessGreenDark
                    )
                }

                items(collectedItems) { item ->
                    InCartItemRow(
                        item = item,
                        onClick = { selectedItemForCollection = item },
                        onRemoveFromCart = { onUpdateCartItem(item.id, 0.0, item.estimatedPrice, false) }
                    )
                }
            }

            // Pending (Pendentes) Section
            item {
                Text(
                    text = "A Coletar (${pendingItems.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            if (pendingItems.isEmpty() && collectedItems.isNotEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SuccessGreenBg,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Todos os itens foram colocados no carrinho! Pode ir para o caixa.",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = SuccessGreenDark
                            )
                        }
                    }
                }
            } else {
                items(pendingItems) { item ->
                    PendingItemRow(
                        item = item,
                        onClick = { selectedItemForCollection = item }
                    )
                }
            }
        }
    }

    // Item Collection Action Sheet
    if (selectedItemForCollection != null) {
        val item = selectedItemForCollection!!
        CollectionDialog(
            item = item,
            currentParticipantName = currentProfile?.name ?: "Você",
            onDismiss = { selectedItemForCollection = null },
            onSave = { qty, price ->
                onUpdateCartItem(item.id, qty, price, true)
                selectedItemForCollection = null
            }
        )
    }

    // Checkout & Cashier Payment Reconciliation Modal
    if (showCheckoutModal) {
        CheckoutReconciliationDialog(
            collectedItems = collectedItems,
            calculatedTotal = totalCollectedAmount,
            onDismiss = { showCheckoutModal = false },
            onConfirmPurchase = { store, subtotal, discount, finalAmt, cashierAmt, method, installments, notes ->
                val purchasedData = collectedItems.map { itm ->
                    CheckoutItemData(
                        listItemId = itm.id,
                        productId = itm.productId,
                        productName = itm.productName,
                        quantity = itm.quantityInCart,
                        unitPrice = if (itm.realPrice > 0) itm.realPrice else itm.estimatedPrice,
                        unit = itm.unit
                    )
                }
                onFinalizeCheckout(
                    store,
                    subtotal,
                    discount,
                    finalAmt,
                    cashierAmt,
                    method,
                    installments,
                    notes,
                    purchasedData
                )
                showCheckoutModal = false
                onBack()
            }
        )
    }
}

@Composable
fun InCartItemRow(
    item: ShoppingListItem,
    onClick: () -> Unit,
    onRemoveFromCart: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SuccessGreenBg.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ProductThumbnail(
                imageUrl = item.imageUrl,
                iconEmoji = item.iconEmoji,
                category = item.category,
                size = 44.dp
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(SuccessGreen),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(10.dp))
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = item.productName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "${item.quantityInCart} ${item.unit} • Corredor: ${item.aisle} • R$ %.2f un • Subtotal: R$ %.2f".format(
                        if (item.realPrice > 0) item.realPrice else item.estimatedPrice,
                        MoneyMath.multiply(if (item.realPrice > 0) item.realPrice else item.estimatedPrice, item.quantityInCart)
                    ),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (item.collectedByName != null) {
                    Text(
                        text = "Coletado por ${item.collectedByName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = SuccessGreenDark,
                        fontSize = 10.sp
                    )
                }
            }

            IconButton(onClick = onRemoveFromCart) {
                Icon(Icons.Default.RemoveShoppingCart, contentDescription = "Retirar", tint = Slate400, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun PendingItemRow(
    item: ShoppingListItem,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ProductThumbnail(
                imageUrl = item.imageUrl,
                iconEmoji = item.iconEmoji,
                category = item.category,
                size = 44.dp
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.productName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${item.quantityPending} ${item.unit} pendentes • Corredor: ${item.aisle} • Est: R$ %.2f".format(item.estimatedPrice),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = onClick,
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("Coletar", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun CollectionDialog(
    item: ShoppingListItem,
    currentParticipantName: String,
    onDismiss: () -> Unit,
    onSave: (qty: Double, price: Double) -> Unit
) {
    var qtyText by remember { mutableStateOf((if (item.quantityInCart > 0.0) item.quantityInCart else item.quantityPending).toString()) }
    var priceText by remember { mutableStateOf((if (item.realPrice > 0) item.realPrice else item.estimatedPrice).toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Coletar Produto", fontWeight = FontWeight.Bold)
                Text(item.productName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = qtyText,
                    onValueChange = { qtyText = it },
                    label = { Text("Quantidade Coletada (${item.unit})") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("Preço Unitário Real (R$)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                            val q = qtyText.replace(",", ".").toDoubleOrNull() ?: 0.0
                val p = priceText.replace(",", ".").toDoubleOrNull() ?: 0.0
                val subtotal = MoneyMath.multiply(p, q)

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = BlueSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "Subtotal: R$ %.2f".format(subtotal),
                            fontWeight = FontWeight.Bold,
                            color = BlueVibrant
                        )
                        Text(
                            text = "Será registrado por $currentParticipantName",
                            style = MaterialTheme.typography.labelSmall,
                            color = Slate600
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val q = qtyText.replace(",", ".").toDoubleOrNull() ?: 0.0
                    val pr = priceText.replace(",", ".").toDoubleOrNull() ?: -1.0
                    onSave(q, pr)
                },
                enabled = qtyText.replace(",", ".").toDoubleOrNull()?.let { it > 0.0 && it <= item.quantityPending } == true &&
                    priceText.replace(",", ".").toDoubleOrNull()?.let { it >= 0.0 } == true
            ) {
                Text("Pôr no Carrinho")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun CheckoutReconciliationDialog(
    collectedItems: List<ShoppingListItem>,
    calculatedTotal: Double,
    onDismiss: () -> Unit,
    onConfirmPurchase: (
        store: String,
        subtotal: Double,
        discount: Double,
        finalAmt: Double,
        cashierAmt: Double,
        method: String,
        installments: Int,
        notes: String
    ) -> Unit
) {
    var storeName by remember { mutableStateOf("") }
    var cashierReportedText by remember { mutableStateOf("%.2f".format(calculatedTotal).replace(".", ",")) }
    var discountText by remember { mutableStateOf("0,00") }
    var paymentMethod by remember { mutableStateOf("Crédito") }
    var installmentsText by remember { mutableStateOf("1") }
    var notes by remember { mutableStateOf("") }
    var confirmedPaid by remember { mutableStateOf(false) }

    val cashierAmt = cashierReportedText.replace(",", ".").toDoubleOrNull() ?: calculatedTotal
    val discountAmt = discountText.replace(",", ".").toDoubleOrNull() ?: 0.0
    val finalAmt = MoneyMath.subtract(calculatedTotal, discountAmt).coerceAtLeast(0.0)
    val difference = MoneyMath.subtract(cashierAmt, finalAmt)
    val installmentsValue = installmentsText.toIntOrNull() ?: 0
    val validCheckout = confirmedPaid && storeName.isNotBlank() && cashierAmt >= 0.0 &&
        discountAmt >= 0.0 && discountAmt <= calculatedTotal &&
        (paymentMethod != "Crédito" || installmentsValue >= 1)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Conferência no Caixa", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = storeName,
                    onValueChange = { storeName = it },
                    label = { Text("Loja / Supermercado *") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = "R$ %.2f".format(calculatedTotal),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Total Carrinho") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = discountText,
                        onValueChange = { discountText = it },
                        label = { Text("Desconto (R$)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = cashierReportedText,
                    onValueChange = { cashierReportedText = it },
                    label = { Text("Total Informado pelo Caixa (R$) *") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                // Divergence Alert
                if (kotlin.math.abs(difference) > 0.05) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = WarningAmberBg,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = WarningAmber)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Diferença detectada de R$ %.2f entre o carrinho e o caixa.".format(difference),
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate800
                            )
                        }
                    }
                }

                // Payment Method
                Text("Método de Pagamento", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Pix", "Crédito", "Débito", "Dinheiro").forEach { m ->
                        FilterChip(
                            selected = paymentMethod == m,
                            onClick = { paymentMethod = m },
                            label = { Text(m) }
                        )
                    }
                }

                if (paymentMethod == "Crédito") {
                    OutlinedTextField(
                        value = installmentsText,
                        onValueChange = { installmentsText = it },
                        label = { Text("Nº de Parcelas") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                // Explicit Confirmation Checkbox (Requirement 8.5)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { confirmedPaid = !confirmedPaid }
                ) {
                    Checkbox(checked = confirmedPaid, onCheckedChange = { confirmedPaid = it })
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Confirmo que o pagamento foi realizado no caixa.",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val inst = if (paymentMethod == "Crédito") installmentsValue else 1
                    onConfirmPurchase(
                        storeName,
                        calculatedTotal,
                        discountAmt,
                        finalAmt,
                        cashierAmt,
                        paymentMethod,
                        inst,
                        notes
                    )
                },
                enabled = validCheckout
            ) {
                Text("Finalizar Compra Real")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}
