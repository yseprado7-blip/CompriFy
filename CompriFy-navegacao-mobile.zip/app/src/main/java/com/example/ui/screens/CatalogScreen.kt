package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.ui.components.ProductImageSelector
import com.example.ui.components.ProductThumbnail
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CatalogScreen(
    products: List<Product>,
    onCreateProduct: (name: String, category: String, brand: String, unit: String, imageUrl: String, iconEmoji: String, aisle: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Todas") }
    var showCreateDialog by remember { mutableStateOf(false) }

    val categories = listOf("Todas", "Alimentação", "Limpeza", "HIGIENE", "HIGIENE PESSOAL")

    val filtered = remember(products, searchQuery, selectedCategory) {
        products.filter { p ->
            (selectedCategory == "Todas" || p.category.equals(selectedCategory, ignoreCase = true)) &&
            (searchQuery.isBlank() || p.name.contains(searchQuery, ignoreCase = true) || p.brand.contains(searchQuery, ignoreCase = true))
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = BlueVibrant,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Novo Produto")
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
        ) {
            item {
                Text(
                    text = "Catálogo de Produtos",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Seu catálogo local de produtos, marcas e embalagens",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = { Text("Buscar no catálogo...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Limpar")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }

            // Categories Filter Chips
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BlueVibrant,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            item {
                Text(
                    text = "Produtos Cadastrados (${filtered.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (filtered.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Category, contentDescription = null, tint = Slate400, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Nenhum produto encontrado neste filtro.", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            } else {
                items(filtered) { prod ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ProductThumbnail(
                                imageUrl = prod.imageUrl,
                                iconEmoji = prod.iconEmoji,
                                category = prod.category,
                                size = 46.dp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = prod.name,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${prod.category} • Corredor: ${prod.aisle} • ${if (prod.brand.isNotBlank()) prod.brand else "Geral"} • Un: ${prod.defaultUnit}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateProductDialog(
            existingProducts = products,
            onDismiss = { showCreateDialog = false },
            onCreate = { name, cat, brand, unit, img, emoji, aisle ->
                onCreateProduct(name, cat, brand, unit, img, emoji, aisle)
                showCreateDialog = false
            }
        )
    }
}

@Composable
fun CreateProductDialog(
    existingProducts: List<Product>,
    onDismiss: () -> Unit,
    onCreate: (String, String, String, String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Alimentação") }
    var brand by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("un") }
    var aisle by remember { mutableStateOf("Geral") }
    var imageUrl by remember { mutableStateOf("") }
    var iconEmoji by remember { mutableStateOf("🌾") }

    val possibleDuplicate = remember(name) {
        if (name.length > 2) {
            existingProducts.find { it.name.contains(name.trim(), ignoreCase = true) }
        } else null
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cadastrar Produto no Catálogo", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nome do Produto *") },
                        placeholder = { Text("ex: Macarrão Espaguete 500g") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                if (possibleDuplicate != null) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = WarningAmberBg,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Aviso de duplicidade: Já existe '${possibleDuplicate.name}' no catálogo.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Slate800
                                )
                            }
                        }
                    }
                }

                item {
                    ProductImageSelector(
                        selectedEmoji = iconEmoji,
                        selectedImageUrl = imageUrl,
                        onSelectEmoji = { iconEmoji = it },
                        onSelectImageUrl = { imageUrl = it }
                    )
                }

                item {
                    Text("Categoria", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Alimentação", "Limpeza", "HIGIENE", "HIGIENE PESSOAL").forEach { c ->
                            FilterChip(
                                selected = category == c,
                                onClick = { category = c },
                                label = { Text(c.take(12)) }
                            )
                        }
                    }
                }

                item {
                    Text("Corredor / Setor", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Grãos", "Laticínios", "Limpeza", "Higiene", "Hortifrúti").forEach { a ->
                            FilterChip(
                                selected = aisle == a,
                                onClick = { aisle = a },
                                label = { Text(a) }
                            )
                        }
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = brand,
                            onValueChange = { brand = it },
                            label = { Text("Marca") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = unit,
                            onValueChange = { unit = it },
                            label = { Text("Unidade (un/kg/L)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onCreate(name, category, brand, unit, imageUrl, iconEmoji, aisle) },
                enabled = name.isNotBlank()
            ) {
                Text("Cadastrar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}
