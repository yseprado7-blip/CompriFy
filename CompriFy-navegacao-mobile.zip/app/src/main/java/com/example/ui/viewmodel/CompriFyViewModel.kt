package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.CompriFyDatabase
import com.example.data.backup.CompriFyBackupService
import android.net.Uri
import com.example.data.model.*
import com.example.data.repository.CheckoutItemData
import com.example.data.repository.CompriFyRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class CompriFyViewModel(application: Application) : AndroidViewModel(application) {

    private val database = CompriFyDatabase.getDatabase(application)
    private val repository = CompriFyRepository(database)
    private val backupService = CompriFyBackupService(database, application.contentResolver)

    val currentProfile: StateFlow<Profile?> = repository.currentProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val shoppingLists: StateFlow<List<ShoppingList>> = repository.allLists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedListId = MutableStateFlow<String?>(null)
    val selectedListId: StateFlow<String?> = _selectedListId.asStateFlow()

    val selectedList: StateFlow<ShoppingList?> = _selectedListId.flatMapLatest { id ->
        if (id != null) repository.getListById(id) else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val selectedListItems: StateFlow<List<ShoppingListItem>> = _selectedListId.flatMapLatest { id ->
        if (id != null) repository.getItemsForList(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.allLists.collect { lists ->
                if (_selectedListId.value == null && lists.isNotEmpty()) {
                    _selectedListId.value = lists.first().id
                }
            }
        }
    }

    val products: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val budgets: StateFlow<List<Budget>> = repository.allBudgets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val purchases: StateFlow<List<Purchase>> = repository.allPurchases
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val prices: StateFlow<List<ProductPrice>> = repository.allPrices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recurrences: StateFlow<List<Recurrence>> = repository.allRecurrences
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val wishlist: StateFlow<List<WishlistItem>> = repository.allWishlist
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activityLogs: StateFlow<List<ActivityLog>> = repository.allLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Audit Timeline Dialog State
    private val _auditDialogState = MutableStateFlow<Pair<String, String>?>(null) // entityId to entityName
    val auditDialogState: StateFlow<Pair<String, String>?> = _auditDialogState.asStateFlow()

    val selectedAuditLogs: StateFlow<List<ActivityLog>> = _auditDialogState.flatMapLatest { pair ->
        if (pair != null) repository.getLogsForEntity(pair.first) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Snackbar notifications
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun showMessage(msg: String) {
        _userMessage.value = msg
    }

    fun updateLocalProfileName(name: String) {
        viewModelScope.launch {
            runCatching { repository.updateLocalProfileName(name) }
                .onSuccess { showMessage("Nome do perfil atualizado.") }
                .onFailure { showMessage(it.message ?: "Não foi possível atualizar o perfil.") }
        }
    }

    fun exportBackup(uri: Uri) {
        viewModelScope.launch {
            runCatching { backupService.export(uri) }
                .onSuccess { showMessage("Backup exportado com sucesso.") }
                .onFailure { showMessage("Não foi possível exportar: ${it.message ?: "erro inesperado"}") }
        }
    }

    fun importBackup(uri: Uri) {
        viewModelScope.launch {
            runCatching { backupService.import(uri) }
                .onSuccess {
                    _selectedListId.value = null
                    showMessage("Backup restaurado. Os dados deste aparelho foram substituídos.")
                }
                .onFailure { showMessage("Backup não restaurado: ${it.message ?: "arquivo inválido"}") }
        }
    }

    // Actions
    fun selectList(listId: String) {
        _selectedListId.value = listId
    }

    fun createShoppingList(
        name: String,
        description: String,
        type: String,
        budgetId: String?
    ) {
        viewModelScope.launch {
            val id = repository.createShoppingList(name, description, type, budgetId)
            _selectedListId.value = id
            showMessage("Lista '$name' criada com sucesso!")
        }
    }

    fun updateListStatus(listId: String, status: String) {
        viewModelScope.launch {
            repository.updateListStatus(listId, status)
            showMessage("Status da lista atualizado para: $status")
        }
    }

    fun deleteShoppingList(listId: String) {
        viewModelScope.launch {
            repository.deleteShoppingList(listId)
            if (_selectedListId.value == listId) {
                _selectedListId.value = shoppingLists.value.firstOrNull { it.id != listId }?.id
            }
            showMessage("Lista excluída.")
        }
    }

    fun addItemToList(
        listId: String,
        productId: String,
        name: String,
        category: String,
        brand: String,
        quantity: Double,
        unit: String,
        estimatedPrice: Double,
        priority: String,
        imageUrl: String = "",
        iconEmoji: String = "📦",
        aisle: String = "Geral"
    ) {
        viewModelScope.launch {
            repository.addItemToList(
                listId = listId,
                productId = productId,
                productName = name,
                category = category,
                brand = brand,
                quantity = quantity,
                unit = unit,
                estimatedPrice = estimatedPrice,
                priority = priority,
                imageUrl = imageUrl,
                iconEmoji = iconEmoji,
                aisle = aisle
            )
            showMessage("'$name' adicionado à lista!")
        }
    }

    fun updateListItemQuantity(itemId: String, delta: Double) {
        viewModelScope.launch {
            repository.updateListItemQuantity(itemId, delta)
        }
    }

    fun updateItemInCart(itemId: String, collectedQuantity: Double, realPrice: Double, inCart: Boolean) {
        viewModelScope.launch {
            repository.updateItemInCart(itemId, collectedQuantity, realPrice, inCart)
        }
    }

    fun deleteListItem(itemId: String) {
        viewModelScope.launch {
            repository.deleteListItem(itemId)
            showMessage("Item removido da lista.")
        }
    }

    fun finalizePurchase(
        listId: String?,
        budgetId: String?,
        storeName: String,
        itemsSubtotal: Double,
        discountTotal: Double,
        finalAmount: Double,
        cashierReportedAmount: Double,
        paymentMethod: String,
        installments: Int,
        notes: String,
        purchasedItemsData: List<CheckoutItemData>,
        onSuccess: (String) -> Unit
    ) {
        viewModelScope.launch {
            val purchaseId = repository.finalizePurchase(
                listId = listId,
                budgetId = budgetId,
                storeName = storeName,
                itemsSubtotal = itemsSubtotal,
                discountTotal = discountTotal,
                finalAmount = finalAmount,
                cashierReportedAmount = cashierReportedAmount,
                paymentMethod = paymentMethod,
                installments = installments,
                notes = notes,
                purchasedItemsData = purchasedItemsData
            )
            showMessage("Compra finalizada e reconciliada com sucesso!")
            onSuccess(purchaseId)
        }
    }

    fun createProduct(
        name: String,
        category: String,
        brand: String,
        unit: String,
        imageUrl: String = "",
        iconEmoji: String = "📦",
        aisle: String = "Geral"
    ) {
        viewModelScope.launch {
            repository.createProduct(name, category, brand, unit, imageUrl, iconEmoji, aisle)
            showMessage("Produto '$name' cadastrado no catálogo!")
        }
    }

    fun createBudget(name: String, type: String, totalAmount: Double, alertThreshold: Int) {
        viewModelScope.launch {
            repository.createBudget(name, type, totalAmount, alertThreshold)
            showMessage("Orçamento '$name' salvo!")
        }
    }

    fun addPrice(productId: String, productName: String, storeName: String, price: Double, unit: String) {
        viewModelScope.launch {
            repository.addPrice(productId, productName, storeName, price, unit)
            showMessage("Preço registrado para '$productName' em '$storeName'!")
        }
    }

    fun createRecurrence(
        productName: String,
        category: String,
        intervalDays: Int,
        intervalLabel: String,
        quantity: Double,
        unit: String,
        store: String,
        refPrice: Double
    ) {
        viewModelScope.launch {
            repository.createRecurrence(productName, category, intervalDays, intervalLabel, quantity, unit, store, refPrice)
            showMessage("Recorrência agendada para '$productName'!")
        }
    }

    fun postponeRecurrence(id: String, days: Int = 7) {
        viewModelScope.launch {
            repository.postponeRecurrence(id, days)
            showMessage("Recorrência adiada em $days dias.")
        }
    }

    fun addWishlistItem(name: String, category: String, targetPrice: Double, priority: String, notes: String) {
        viewModelScope.launch {
            repository.addWishlistItem(name, category, targetPrice, priority, notes)
            showMessage("Item adicionado à lista de desejos!")
        }
    }

    fun moveWishlistItemToList(item: WishlistItem, targetListId: String) {
        viewModelScope.launch {
            repository.addItemToList(
                listId = targetListId,
                productId = item.id,
                productName = item.productName,
                category = item.category,
                brand = "",
                quantity = 1.0,
                unit = "un",
                estimatedPrice = item.targetPrice,
                priority = if (item.priority.contains("Alta")) "Alta" else "Média"
            )
            repository.deleteWishlistItem(item.id)
            showMessage("'${item.productName}' movido para a lista de compras!")
        }
    }

    fun deleteWishlistItem(id: String) {
        viewModelScope.launch {
            repository.deleteWishlistItem(id)
            showMessage("Item removido dos desejos.")
        }
    }

    // Audit Modal
    fun openAudit(entityId: String, entityName: String) {
        _auditDialogState.value = Pair(entityId, entityName)
    }

    fun closeAudit() {
        _auditDialogState.value = null
    }
}
