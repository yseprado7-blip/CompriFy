package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// CompriFy Brand Colors
val NavyDark = Color(0xFF0B1B3D)
val NavyPrimary = Color(0xFF0F2B5C)
val NavyLight = Color(0xFF1E3A8A)

val BlueVibrant = Color(0xFF2563EB)
val BlueAccent = Color(0xFF3B82F6)
val BlueSky = Color(0xFF38BDF8)
val BlueSurface = Color(0xFFEFF6FF)

val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

// Semantic Accents
val SuccessGreen = Color(0xFF10B981)
val SuccessGreenDark = Color(0xFF047857)
val SuccessGreenBg = Color(0xFFECFDF5)

val WarningAmber = Color(0xFFF59E0B)
val WarningAmberBg = Color(0xFFFFFBEB)

val DangerRed = Color(0xFFEF4444)
val DangerRedBg = Color(0xFFFEF2F2)

val CategoryPurple = Color(0xFF8B5CF6)
val CategoryPurpleBg = Color(0xFFF5F3FF)
