package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Budget
import com.example.data.model.Purchase
import com.example.data.util.MoneyMath
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BudgetScreen(
    budgets: List<Budget>,
    purchases: List<Purchase>,
    onCreateBudget: (name: String, type: String, totalAmount: Double, alertThreshold: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var showCreateDialog by remember { mutableStateOf(false) }

    val totalBudget = MoneyMath.sum(budgets.map { it.totalAmount })
    val finalizedPurchases = purchases.filter { it.status == "Finalizada" }
    val totalPurchased = MoneyMath.sum(finalizedPurchases.map { it.finalAmount })
    val availableBalance = MoneyMath.subtract(totalBudget, totalPurchased).coerceAtLeast(0.0)
    val percentUsed = if (totalBudget > 0) ((totalPurchased / totalBudget) * 100).toInt() else 0

    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = BlueVibrant,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Novo Orçamento")
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
        ) {
            item {
                Text(
                    text = "Orçamentos de Compras",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Controle de limites financeiros vinculados exclusivamente a compras",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Big Summary Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(text = "Visão Consolidada do Mês", style = MaterialTheme.typography.labelMedium, color = Slate400)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "R$ %.2f".format(totalBudget),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "Total Comprado", style = MaterialTheme.typography.labelSmall, color = Slate400)
                                Text(
                                    text = "R$ %.2f".format(totalPurchased),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (percentUsed > 80) WarningAmber else SuccessGreen
                                )
                            }
                            Column {
                                Text(text = "Saldo Disponível", style = MaterialTheme.typography.labelSmall, color = Slate400)
                                Text(
                                    text = "R$ %.2f".format(availableBalance),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = BlueSky
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        LinearProgressIndicator(
                            progress = { (percentUsed / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (percentUsed >= 90) WarningAmber else BlueVibrant,
                            trackColor = Slate800
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "$percentUsed% consumido • Saldo restante seguro",
                            style = MaterialTheme.typography.labelSmall,
                            color = Slate400
                        )
                    }
                }
            }

            // Individual Budgets
            item {
                Text(
                    text = "Tetos Orçamentários Definidos",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            items(budgets) { budget ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = budget.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "Tipo: ${budget.type} • Alerta em ${budget.alertThresholdPercent}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "R$ %.2f".format(budget.totalAmount),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            // Realized Purchases Linked to Budgets
            item {
                Text(
                    text = "Compras Efetivamente Registradas (${finalizedPurchases.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            if (finalizedPurchases.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = Slate400, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Nenhuma compra finalizada ainda neste período.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(finalizedPurchases) { purchase ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = purchase.storeName,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${dateFormat.format(Date(purchase.purchaseDate))} • ${purchase.paymentMethod} • Por ${purchase.responsibleParticipantName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (purchase.installments > 1) {
                                    Text(
                                        text = "${purchase.installments}x de R$ %.2f (Parcela atual considerada)".format(purchase.installmentValue),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = BlueVibrant,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Text(
                                text = "R$ %.2f".format(purchase.finalAmount),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = SuccessGreenDark
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateBudgetDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { name, type, amt, thresh ->
                onCreateBudget(name, type, amt, thresh)
                showCreateDialog = false
            }
        )
    }
}

@Composable
fun CreateBudgetDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, type: String, amount: Double, threshold: Int) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Principal") }
    var amountText by remember { mutableStateOf("") }
    var thresholdText by remember { mutableStateOf("80") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Novo Orçamento de Compras", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome do Orçamento *") },
                    placeholder = { Text("ex: Feira Semanal, Compras Mensais") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Teto Máximo (R$) *") },
                    placeholder = { Text("1200.00") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Text("Tipo de Orçamento", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Principal", "Extraordinário", "Recorrente").forEach { t ->
                        FilterChip(
                            selected = type == t,
                            onClick = { type = t },
                            label = { Text(t) }
                        )
                    }
                }

                OutlinedTextField(
                    value = thresholdText,
                    onValueChange = { thresholdText = it },
                    label = { Text("Limite de Alerta (%)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.replace(",", ".").toDoubleOrNull() ?: 0.0
                    val th = thresholdText.toIntOrNull() ?: 80
                    onCreate(name, type, amt, th)
                },
                enabled = name.isNotBlank() && amountText.isNotBlank()
            ) {
                Text("Criar Orçamento")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}
