package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Profile

@Composable
fun ParticipantAvatar(
    name: String,
    initials: String,
    colorHex: String,
    modifier: Modifier = Modifier,
    size: Dp = 32.dp,
    onClick: (() -> Unit)? = null
) {
    val bgColor = try {
        Color(android.graphics.Color.parseColor(colorHex))
    } catch (e: Exception) {
        MaterialTheme.colorScheme.primary
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(bgColor)
            .border(1.5.dp, MaterialTheme.colorScheme.surface, CircleShape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = initials.take(2).uppercase(),
            color = Color.White,
            fontSize = (size.value * 0.42f).sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun OverlappingAvatars(
    profiles: List<Profile>,
    modifier: Modifier = Modifier,
    avatarSize: Dp = 28.dp,
    maxShow: Int = 3,
    onClick: (() -> Unit)? = null
) {
    val displayed = profiles.take(maxShow)
    val remaining = profiles.size - maxShow

    Row(
        modifier = modifier.then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            displayed.forEachIndexed { index, profile ->
                Box(modifier = Modifier.padding(start = (index * 18).dp)) {
                    ParticipantAvatar(
                        name = profile.name,
                        initials = profile.initials,
                        colorHex = profile.colorHex,
                        size = avatarSize
                    )
                }
            }
        }
        if (remaining > 0) {
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "+$remaining",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
