package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.data.model.ProductPrice
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PriceComparisonScreen(
    prices: List<ProductPrice>,
    products: List<Product>,
    onAddPrice: (productId: String, productName: String, storeName: String, price: Double, unit: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }

    // Group prices by product
    val grouped = remember(prices) {
        prices.groupBy { it.productName }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = SuccessGreen,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Registrar Preço")
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
        ) {
            item {
                Text(
                    text = "Comparador de Preços",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Compare o mesmo produto entre lojas e economize",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (grouped.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.PriceCheck, contentDescription = null, tint = Slate400, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Nenhum histórico de preço registrado ainda.", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            } else {
                items(grouped.entries.toList()) { entry ->
                    val productName = entry.key
                    val priceList = entry.value.sortedBy { it.price }
                    val lowest = priceList.firstOrNull()

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = productName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )

                                if (lowest != null) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = SuccessGreenBg
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.TrendingDown, contentDescription = null, tint = SuccessGreenDark, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "Menor: R$ %.2f (${lowest.storeName})".format(lowest.price),
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = SuccessGreenDark
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(10.dp))

                            // Store comparison rows
                            priceList.forEach { p ->
                                val isLowest = p.id == lowest?.id
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = p.storeName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = if (isLowest) FontWeight.Bold else FontWeight.Normal
                                        )
                                        Text(
                                            text = "Origem: ${p.source} • Reg. por ${p.registeredBy}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 10.sp
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "R$ %.2f".format(p.price),
                                            style = MaterialTheme.typography.bodyLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isLowest) SuccessGreenDark else MaterialTheme.colorScheme.onSurface
                                        )
                                        if (p.pricePerUnit > 0) {
                                            Text(
                                                text = "R$ %.2f / ${p.unit}".format(p.pricePerUnit),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 10.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddPriceDialog(
            products = products,
            onDismiss = { showAddDialog = false },
            onAdd = { pId, pName, store, price, unit ->
                onAddPrice(pId, pName, store, price, unit)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun AddPriceDialog(
    products: List<Product>,
    onDismiss: () -> Unit,
    onAdd: (productId: String, productName: String, store: String, price: Double, unit: String) -> Unit
) {
    var productName by remember { mutableStateOf(products.firstOrNull()?.name ?: "") }
    var storeName by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("un") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar Preço Encontrado", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = productName,
                    onValueChange = { productName = it },
                    label = { Text("Nome do Produto *") },
                    placeholder = { Text("ex: Arroz Tipo 1") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = storeName,
                    onValueChange = { storeName = it },
                    label = { Text("Supermercado / Loja *") },
                    placeholder = { Text("ex: Carrefour, Atacadão") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("Preço (R$) *") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Unidade (un/kg/L)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val pr = priceText.replace(",", ".").toDoubleOrNull() ?: 0.0
                    val matchedId = products.find { it.name.equals(productName.trim(), ignoreCase = true) }?.id ?: "prod_custom"
                    onAdd(matchedId, productName, storeName, pr, unit)
                },
                enabled = productName.isNotBlank() && storeName.isNotBlank() && priceText.isNotBlank()
            ) {
                Text("Registrar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}
