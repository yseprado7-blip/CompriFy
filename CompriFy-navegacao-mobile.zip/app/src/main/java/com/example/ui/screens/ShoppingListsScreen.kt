package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.util.MoneyMath
import com.example.ui.components.ParticipantAvatar
import com.example.ui.components.ProductImageSelector
import com.example.ui.components.ProductThumbnail
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingListsScreen(
    lists: List<ShoppingList>,
    selectedListId: String?,
    budgets: List<Budget>,
    products: List<Product>,
    listItems: List<ShoppingListItem>,
    onSelectList: (String) -> Unit,
    onCreateList: (name: String, description: String, type: String, budgetId: String?) -> Unit,
    onDeleteList: (String) -> Unit,
    onStartShoppingMode: (String) -> Unit,
    onAddItemToList: (listId: String, productId: String, name: String, category: String, brand: String, quantity: Double, unit: String, price: Double, priority: String, imageUrl: String, iconEmoji: String, aisle: String) -> Unit,
    onUpdateQuantity: (itemId: String, delta: Double) -> Unit,
    onDeleteItem: (String) -> Unit,
    onOpenAudit: (entityId: String, entityName: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showCreateModal by remember { mutableStateOf(false) }
    var showAddItemModal by remember { mutableStateOf(false) }
    var selectedFilter by remember { mutableStateOf("Todas") }
    var groupByAisle by remember { mutableStateOf(true) }

    val activeList = lists.find { it.id == selectedListId } ?: lists.firstOrNull()

    val filteredLists = remember(lists, selectedFilter) {
        when (selectedFilter) {
            "Mensal" -> lists.filter { it.type == "Mensal" }
            "Semanal" -> lists.filter { it.type == "Semanal" }
            "Concluídas" -> lists.filter { it.status == "Concluída" }
            else -> lists
        }
    }

    // Grouping items either by Aisle or flat
    val groupedItems = remember(listItems, groupByAisle) {
        if (groupByAisle) {
            listItems.groupBy { if (it.aisle.isNotBlank()) it.aisle else "Corredor Geral" }
        } else {
            mapOf("Todos os Itens" to listItems)
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (activeList != null) showAddItemModal = true else showCreateModal = true
                },
                containerColor = BlueVibrant,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Adicionar Produto")
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
        ) {
            // Header with Create New List CTA
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Listas de Compras",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Planeje produtos com fotos, quantidades e corredores",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    OutlinedButton(
                        onClick = { showCreateModal = true },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.PlaylistAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Nova Lista")
                    }
                }
            }

            // Filter Tabs
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Todas", "Mensal", "Semanal", "Concluídas").forEach { filter ->
                        val isSelected = selectedFilter == filter
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedFilter = filter },
                            label = { Text(filter) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BlueVibrant,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            // Horizontal Selector for Lists
            if (filteredLists.isNotEmpty()) {
                item {
                    Text(
                        text = "Suas Listas (${filteredLists.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        filteredLists.forEach { list ->
                            val isSelected = list.id == activeList?.id
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                border = if (isSelected) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onSelectList(list.id) }
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = list.name,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = "${list.type} • ${list.status}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Active List Detail Section
            if (activeList != null) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = activeList.name,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (activeList.description.isNotBlank()) {
                                        Text(
                                            text = activeList.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Row {
                                    // Share Text checklist button
                                    IconButton(onClick = {
                                        shareListAsText(context, activeList.name, listItems)
                                    }) {
                                        Icon(Icons.Default.Share, contentDescription = "Compartilhar lista", tint = BlueVibrant)
                                    }

                                    // Delete list option
                                    IconButton(onClick = { onDeleteList(activeList.id) }) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Excluir lista", tint = DangerRed)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Shared Participants row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Salva neste aparelho",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (activeList.status == "Concluída") SuccessGreenBg else BlueSurface
                                ) {
                                    Text(
                                        text = activeList.status,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (activeList.status == "Concluída") SuccessGreen else BlueVibrant,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Big CTA to enter In-Store Digital Cart Mode
                            Button(
                                onClick = { onStartShoppingMode(activeList.id) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = NavyDark)
                            ) {
                                Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Abrir no Carrinho Digital (Presencial)")
                            }
                        }
                    }
                }

                // Section Controls: Group by Aisle toggle & Total Estimation
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Itens na Lista (${listItems.size})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            val totalEst = MoneyMath.sum(listItems.map { MoneyMath.multiply(it.estimatedPrice, it.quantityPlanned) })
                            Text(
                                text = "Estimativa Total: R$ %.2f".format(totalEst),
                                style = MaterialTheme.typography.labelSmall,
                                color = SuccessGreenDark,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Toggle Group by Aisle
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Por Corredor",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Switch(
                                checked = groupByAisle,
                                onCheckedChange = { groupByAisle = it },
                                modifier = Modifier.height(28.dp)
                            )
                        }
                    }
                }

                if (listItems.isEmpty()) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.PlaylistAddCheck, contentDescription = null, tint = Slate400, modifier = Modifier.size(40.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Nenhum produto adicionado nesta lista ainda.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                FilledTonalButton(onClick = { showAddItemModal = true }) {
                                    Text("Adicionar Primeiro Produto com Imagem")
                                }
                            }
                        }
                    }
                } else {
                    // Render items grouped by aisle or category
                    groupedItems.forEach { (aisleName, itemsInAisle) ->
                        if (groupByAisle) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = BlueSurface,
                                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Storefront, contentDescription = null, tint = BlueVibrant, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = aisleName,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = NavyPrimary
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "(${itemsInAisle.size})",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Slate600
                                        )
                                    }
                                }
                            }
                        }

                        items(itemsInAisle) { item ->
                            RichListItemCard(
                                item = item,
                                onOpenAudit = { onOpenAudit(item.id, item.productName) },
                                onIncrement = { onUpdateQuantity(item.id, 1.0) },
                                onDecrement = { onUpdateQuantity(item.id, -1.0) },
                                onDelete = { onDeleteItem(item.id) }
                            )
                        }
                    }
                }
            }
        }
    }

    // Modal: Create List
    if (showCreateModal) {
        CreateListDialog(
            budgets = budgets,
            onDismiss = { showCreateModal = false },
            onCreate = { name, desc, type, bId ->
                onCreateList(name, desc, type, bId)
                showCreateModal = false
            }
        )
    }

    // Modal: Add Item with Rich Image & Aisle Selector
    if (showAddItemModal && activeList != null) {
        AddRichItemDialog(
            products = products,
            onDismiss = { showAddItemModal = false },
            onAdd = { pId, pName, cat, brand, qty, unit, price, priority, imgUrl, emoji, aisle ->
                onAddItemToList(activeList.id, pId, pName, cat, brand, qty, unit, price, priority, imgUrl, emoji, aisle)
                showAddItemModal = false
            }
        )
    }
}

@Composable
fun RichListItemCard(
    item: ShoppingListItem,
    onOpenAudit: () -> Unit,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Product Visual Thumbnail (Emoji or Image)
            ProductThumbnail(
                imageUrl = item.imageUrl,
                iconEmoji = item.iconEmoji,
                category = item.category,
                size = 48.dp
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = item.productName,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )

                    val priorityColor = when (item.priority) {
                        "Alta" -> DangerRed
                        "Média" -> WarningAmber
                        else -> BlueVibrant
                    }
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = priorityColor.copy(alpha = 0.12f)
                    ) {
                        Text(
                            text = item.priority,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = priorityColor,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "R$ %.2f un".format(item.estimatedPrice),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(text = " • ", color = Slate400)
                    Text(
                        text = "Subtotal: R$ %.2f".format(MoneyMath.multiply(item.estimatedPrice, item.quantityPlanned)),
                        style = MaterialTheme.typography.bodySmall,
                        color = SuccessGreenDark,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Quantity adjusters + Trello-style creator badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Creator avatar with click-to-audit affordance
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable(onClick = onOpenAudit)
                    ) {
                        ParticipantAvatar(
                            name = item.creatorName,
                            initials = item.creatorInitials,
                            colorHex = "#2563EB",
                            size = 22.dp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = item.creatorName.substringBefore(" "),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    }

                    // Direct Quick Quantity Buttons (+ / -)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        IconButton(
                            onClick = onDecrement,
                            modifier = Modifier.size(26.dp)
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Diminuir", modifier = Modifier.size(16.dp))
                        }

                        Text(
                            text = "${item.quantityPlanned.toInt()} ${item.unit}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        )

                        IconButton(
                            onClick = onIncrement,
                            modifier = Modifier.size(26.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Aumentar", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.DeleteOutline, contentDescription = "Remover", tint = Slate400, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun AddRichItemDialog(
    products: List<Product>,
    onDismiss: () -> Unit,
    onAdd: (
        productId: String,
        name: String,
        category: String,
        brand: String,
        quantity: Double,
        unit: String,
        price: Double,
        priority: String,
        imageUrl: String,
        iconEmoji: String,
        aisle: String
    ) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Alimentação") }
    var brand by remember { mutableStateOf("") }
    var quantityText by remember { mutableStateOf("1") }
    var unit by remember { mutableStateOf("un") }
    var priceText by remember { mutableStateOf("0.00") }
    var priority by remember { mutableStateOf("Média") }
    var selectedEmoji by remember { mutableStateOf("🌾") }
    var selectedImageUrl by remember { mutableStateOf("") }
    var aisle by remember { mutableStateOf("Corredor 1: Grãos & Cereais") }

    val aislePresets = listOf(
        "Corredor 1: Grãos & Cereais",
        "Corredor 2: Laticínios & Frios",
        "Corredor 3: Mercearia & Óleos",
        "Corredor 4: Limpeza & Lavanderia",
        "Corredor 5: Higiene & Banho",
        "Hortifruti & Padaria",
        "Carnes & Congelados"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Adicionar Produto com Imagem", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(androidx.compose.foundation.rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Visual Image Selector Component
                ProductImageSelector(
                    selectedEmoji = selectedEmoji,
                    selectedImageUrl = selectedImageUrl,
                    onSelectEmoji = { selectedEmoji = it },
                    onSelectImageUrl = { selectedImageUrl = it }
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome do Produto *") },
                    placeholder = { Text("ex: Arroz Integral 1kg") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("Qtd *") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Unidade") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("Preço Est. (R$)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = brand,
                        onValueChange = { brand = it },
                        label = { Text("Marca") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Text("Corredor / Setor do Mercado", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(androidx.compose.foundation.rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    aislePresets.forEach { a ->
                        FilterChip(
                            selected = aisle == a,
                            onClick = { aisle = a },
                            label = { Text(a.substringBefore(":")) }
                        )
                    }
                }

                Text("Prioridade", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Alta", "Média", "Baixa").forEach { p ->
                        FilterChip(
                            selected = priority == p,
                            onClick = { priority = p },
                            label = { Text(p) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val q = quantityText.toDoubleOrNull() ?: 1.0
                        val pr = priceText.replace(",", ".").toDoubleOrNull() ?: 0.0
                        onAdd("prod_${System.currentTimeMillis()}", name, category, brand, q, unit, pr, priority, selectedImageUrl, selectedEmoji, aisle)
                    }
                },
                enabled = name.isNotBlank()
            ) {
                Text("Adicionar à Lista")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

@Composable
fun CreateListDialog(
    budgets: List<Budget>,
    onDismiss: () -> Unit,
    onCreate: (name: String, description: String, type: String, budgetId: String?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Mensal") }
    var selectedBudgetId by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nova Lista de Compras", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome da Lista *") },
                    placeholder = { Text("ex: Rancho do Mês") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Descrição / Observações") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Text("Tipo de Lista", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Mensal", "Semanal", "Churrasco", "Farmácia", "Geral").forEach { t ->
                        FilterChip(
                            selected = type == t,
                            onClick = { type = t },
                            label = { Text(t) }
                        )
                    }
                }

                if (budgets.isNotEmpty()) {
                    Text("Vincular a um Orçamento", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = selectedBudgetId == null,
                            onClick = { selectedBudgetId = null },
                            label = { Text("Nenhum") }
                        )
                        budgets.forEach { b ->
                            FilterChip(
                                selected = selectedBudgetId == b.id,
                                onClick = { selectedBudgetId = b.id },
                                label = { Text(b.name) }
                            )
                        }
                    }
                }


            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onCreate(name, description, type, selectedBudgetId)
                    }
                },
                enabled = name.isNotBlank()
            ) {
                Text("Criar Lista")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

private fun shareListAsText(context: Context, listName: String, items: List<ShoppingListItem>) {
    val builder = StringBuilder()
    builder.append("🛒 CompriFy — $listName\n\n")
    items.forEach { item ->
        val statusSymbol = if (item.status == "Comprado" || item.status == "No Carrinho") "✅" else "⬜"
        builder.append("$statusSymbol ${item.iconEmoji} ${item.productName}: ${item.quantityPlanned.toInt()} ${item.unit} (~R$ %.2f)\n".format(item.estimatedPrice))
    }
    val total = MoneyMath.sum(items.map { MoneyMath.multiply(it.estimatedPrice, it.quantityPlanned) })
    builder.append("\n💰 Estimativa Total: R$ %.2f\n".format(total))
    builder.append("Planeje • Compare • Compre com CompriFy")

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, builder.toString())
    }
    context.startActivity(Intent.createChooser(intent, "Compartilhar Lista de Compras"))
}
