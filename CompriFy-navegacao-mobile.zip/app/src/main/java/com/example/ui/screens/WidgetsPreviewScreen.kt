package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.util.MoneyMath
import com.example.ui.theme.*

@Composable
fun WidgetsPreviewScreen(
    activeList: ShoppingList?,
    items: List<ShoppingListItem>,
    budgets: List<Budget>,
    purchases: List<Purchase>,
    recurrences: List<Recurrence>,
    onToggleItemInCart: (itemId: String, currentStatus: String) -> Unit,
    onQuickAddProduct: (name: String, qty: Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val totalBudget = MoneyMath.sum(budgets.map { it.totalAmount })
    val totalPurchased = MoneyMath.sum(purchases.filter { it.status == "Finalizada" }.map { it.finalAmount })
    val availableBalance = MoneyMath.subtract(totalBudget, totalPurchased).coerceAtLeast(0.0)
    val budgetPercent = if (totalBudget > 0) ((totalPurchased / totalBudget) * 100).toInt() else 0
    val pendingItems = items.filter { it.status == "Pendente" }

    var quickAddName by remember { mutableStateOf("") }
    var quickAddQty by remember { mutableStateOf("1") }
    var quickAddFeedback by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp)
    ) {
        item {
            Text(
                text = "Prévia de widgets do CompriFy",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Demonstração visual dos formatos planejados. Estes cartões ainda não são widgets instaláveis na tela inicial do Android.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Widget 1 — Compacto (2x1)
        item {
            WidgetContainer(title = "Widget 1 — Compacto (2×1)") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(BlueVibrant))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("CompriFy", fontWeight = FontWeight.Black, fontSize = 14.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${pendingItems.size} itens pendentes",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (budgetPercent > 80) WarningAmberBg else SuccessGreenBg
                    ) {
                        Text(
                            text = "Saldo: R$ %.0f".format(availableBalance),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (budgetPercent > 80) WarningAmber else SuccessGreenDark,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Widget 2 — Resumo (2x2)
        item {
            WidgetContainer(title = "Widget 2 — Resumo Orçamento (2×2)") {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Orçamento Mês", style = MaterialTheme.typography.labelSmall, color = Slate400)
                        Text("$budgetPercent% usado", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = BlueVibrant)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "R$ %.2f".format(totalBudget),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { (budgetPercent / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = BlueVibrant,
                        trackColor = Slate200
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Utilizado", style = MaterialTheme.typography.labelSmall, color = Slate400)
                            Text("R$ %.2f".format(totalPurchased), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Disponível", style = MaterialTheme.typography.labelSmall, color = Slate400)
                            Text("R$ %.2f".format(availableBalance), fontWeight = FontWeight.Bold, color = SuccessGreenDark, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }

        // Widget 3 — Completo (4x2)
        item {
            WidgetContainer(title = "Widget 3 — Completo (4×2)") {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("CompriFy • ${activeList?.name ?: "Lista Ativa"}", fontWeight = FontWeight.Bold)
                            Text("${pendingItems.size} pendentes na lista", style = MaterialTheme.typography.labelSmall, color = Slate600)
                        }
                        Text("Local", style = MaterialTheme.typography.labelSmall, color = Slate600)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Orçamento: R$ %.2f".format(totalBudget), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                        Text("Saldo: R$ %.2f".format(availableBalance), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SuccessGreenDark)
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    val listProg = if (items.isNotEmpty()) items.count { it.status == "No Carrinho" }.toFloat() / items.size else 0f
                    LinearProgressIndicator(
                        progress = { listProg },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = SuccessGreen,
                        trackColor = Slate200
                    )
                }
            }
        }

        // Widget 4 — Expandido (4x4)
        item {
            WidgetContainer(title = "Widget 4 — Expandido (4×4)") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("CompriFy Dashboard", fontWeight = FontWeight.Black)
                        Surface(shape = RoundedCornerShape(6.dp), color = BlueSurface) {
                            Text("Família Souza", style = MaterialTheme.typography.labelSmall, color = BlueVibrant, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }

                    Text("Lista: ${activeList?.name ?: "Compras do Mês"}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    Text("Saldo Orçamentário Restante: R$ %.2f".format(availableBalance), style = MaterialTheme.typography.bodySmall, color = SuccessGreenDark, fontWeight = FontWeight.Bold)

                    Text("Próxima Recorrência:", style = MaterialTheme.typography.labelSmall, color = Slate400)
                    recurrences.firstOrNull()?.let { rec ->
                        Surface(shape = RoundedCornerShape(8.dp), color = Slate100, modifier = Modifier.fillMaxWidth()) {
                            Row(modifier = Modifier.padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(rec.productName, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                Text("R$ %.2f".format(rec.referencePrice), style = MaterialTheme.typography.bodySmall, color = BlueVibrant, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Widget 5 — Lista Interativa (Ações diretas do Widget na Home!)
        item {
            WidgetContainer(title = "Widget 5 — Lista Interativa (Marcação Direta)") {
                Column {
                    Text(
                        text = "Toque para coletar/desmarcar itens diretamente da tela inicial:",
                        style = MaterialTheme.typography.labelSmall,
                        color = Slate600
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    items.take(4).forEach { item ->
                        val isChecked = item.status == "No Carrinho"
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { onToggleItemInCart(item.id, item.status) }
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = item.productName,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = if (isChecked) FontWeight.Normal else FontWeight.Bold
                                    )
                                    Text(
                                        text = "${item.quantityPlanned} ${item.unit} • Adicionado por ${item.creatorName}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Slate400,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            Text(
                                text = "R$ %.2f".format(item.estimatedPrice),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isChecked) SuccessGreenDark else NavyPrimary
                            )
                        }
                    }
                }
            }
        }

        // Widget 6 — Adição Rápida
        item {
            WidgetContainer(title = "Widget 6 — Adição Rápida de Produto") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Adicione produto diretamente para a lista ativa sem abrir telas complexas:",
                        style = MaterialTheme.typography.labelSmall,
                        color = Slate600
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = quickAddName,
                            onValueChange = { quickAddName = it },
                            placeholder = { Text("Nome do produto") },
                            modifier = Modifier.weight(2f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = quickAddQty,
                            onValueChange = { quickAddQty = it },
                            placeholder = { Text("Qtd") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    Button(
                        onClick = {
                            if (quickAddName.isNotBlank()) {
                                val q = quickAddQty.toDoubleOrNull() ?: 1.0
                                onQuickAddProduct(quickAddName, q)
                                quickAddFeedback = "'$quickAddName' adicionado via widget!"
                                quickAddName = ""
                            }
                        },
                        enabled = quickAddName.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NavyDark)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Adicionar Diretamente")
                    }

                    if (quickAddFeedback != null) {
                        Text(
                            text = quickAddFeedback!!,
                            style = MaterialTheme.typography.labelSmall,
                            color = SuccessGreenDark,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun WidgetContainer(
    title: String,
    content: @Composable () -> Unit
) {
    Column {
        Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline),
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(modifier = Modifier.padding(16.dp)) {
                content()
            }
        }
    }
}
