package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.util.MoneyMath
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    selectedList: ShoppingList?,
    listItems: List<ShoppingListItem>,
    budgets: List<Budget>,
    purchases: List<Purchase>,
    recurrences: List<Recurrence>,
    activityLogs: List<ActivityLog>,
    currentProfile: Profile?,
    onNavigateToListDetail: (String) -> Unit,
    onStartShoppingMode: (String) -> Unit,
    onNavigateToCatalog: () -> Unit,
    onNavigateToPrices: () -> Unit,
    onNavigateToBudget: () -> Unit,
    onNavigateToRecurrences: () -> Unit,
    onNavigateToWishlist: () -> Unit,
    onNavigateToWidgets: () -> Unit,
    onNavigateToHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val totalBudget = MoneyMath.sum(budgets.map { it.totalAmount })
    val totalPurchased = MoneyMath.sum(purchases.filter { it.status == "Finalizada" }.map { it.finalAmount })
    val availableBalance = MoneyMath.subtract(totalBudget, totalPurchased).coerceAtLeast(0.0)
    val budgetPercent = if (totalBudget > 0) ((totalPurchased / totalBudget) * 100).toInt() else 0

    val pendingCount = listItems.count { it.status == "Pendente" }
    val inCartCount = listItems.count { it.status == "No Carrinho" }
    val completedCount = listItems.count { it.status == "Comprado" }
    val totalItems = listItems.size
    val listProgress = if (totalItems > 0) ((completedCount + inCartCount).toFloat() / totalItems) else 0f

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp)
    ) {
        // Welcome Header & Session Greeting
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = NavyDark),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Olá, ${currentProfile?.name?.substringBefore(" ") ?: "Usuário"}!",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Seus dados neste aparelho",
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate400
                            )
                        }

                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = Slate800)
                    Spacer(modifier = Modifier.height(14.dp))

                    // Budget summary cards inside hero
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Orçamento Mensal", style = MaterialTheme.typography.labelSmall, color = Slate400)
                            Text(
                                text = "R$ %.2f".format(totalBudget),
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Column {
                            Text(text = "Realizado", style = MaterialTheme.typography.labelSmall, color = Slate400)
                            Text(
                                text = "R$ %.2f".format(totalPurchased),
                                style = MaterialTheme.typography.titleMedium,
                                color = if (budgetPercent > 90) WarningAmber else SuccessGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Column {
                            Text(text = "Saldo Disponível", style = MaterialTheme.typography.labelSmall, color = Slate400)
                            Text(
                                text = "R$ %.2f".format(availableBalance),
                                style = MaterialTheme.typography.titleMedium,
                                color = BlueSky,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { (budgetPercent / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (budgetPercent > 90) WarningAmber else BlueVibrant,
                        trackColor = Slate800
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$budgetPercent% do orçamento utilizado no período",
                        style = MaterialTheme.typography.labelSmall,
                        color = Slate400,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Active List & Quick Start "Modo Comprando"
        item {
            if (selectedList != null) {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = BlueSurface,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                ) {
                                    Text(
                                        text = "LISTA ATIVA EM DESTAQUE",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = BlueVibrant,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                                Text(
                                    text = selectedList.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "$totalItems produtos planejados • $pendingCount pendentes",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            IconButton(onClick = { onNavigateToListDetail(selectedList.id) }) {
                                Icon(Icons.Default.ArrowForwardIos, contentDescription = "Ver lista", modifier = Modifier.size(18.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Progress metric bar
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LinearProgressIndicator(
                                progress = { listProgress },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(5.dp)),
                                color = SuccessGreen,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "${(listProgress * 100).toInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Fast Shopping Mode CTA
                        Button(
                            onClick = { onStartShoppingMode(selectedList.id) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BlueVibrant)
                        ) {
                            Icon(Icons.Default.ShoppingCartCheckout, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Iniciar Modo Comprando (Carrinho Digital)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Quick Feature Grid (Preserving the 10 features from the brief)
        item {
            Text(
                text = "Recursos & Planejamento",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FeatureShortcutCard(
                        title = "Catálogo",
                        subtitle = "Produtos & Marcas",
                        icon = Icons.Default.Category,
                        iconBg = BlueSurface,
                        iconTint = BlueVibrant,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToCatalog
                    )
                    FeatureShortcutCard(
                        title = "Comparar Preços",
                        subtitle = "Menor valor por loja",
                        icon = Icons.Default.PriceCheck,
                        iconBg = SuccessGreenBg,
                        iconTint = SuccessGreen,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToPrices
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FeatureShortcutCard(
                        title = "Orçamentos",
                        subtitle = "Tetos & Alertas",
                        icon = Icons.Default.AccountBalanceWallet,
                        iconBg = WarningAmberBg,
                        iconTint = WarningAmber,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToBudget
                    )
                    FeatureShortcutCard(
                        title = "Recorrências",
                        subtitle = "Compras periódicas",
                        icon = Icons.Default.Repeat,
                        iconBg = CategoryPurpleBg,
                        iconTint = CategoryPurple,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToRecurrences
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FeatureShortcutCard(
                        title = "Desejos",
                        subtitle = "Lista de futuras compras",
                        icon = Icons.Default.FavoriteBorder,
                        iconBg = Color(0xFFFDF2F8),
                        iconTint = Color(0xFFDB2777),
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToWishlist
                    )
                    FeatureShortcutCard(
                        title = "Widgets Android",
                        subtitle = "6 Formatos interativos",
                        icon = Icons.Default.Widgets,
                        iconBg = Color(0xFFF0FDF4),
                        iconTint = Color(0xFF16A34A),
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToWidgets
                    )
                }
            }
        }

        // Upcoming Recurrences Preview
        if (recurrences.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recorrências Próximas",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = onNavigateToRecurrences) {
                        Text("Ver todas")
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    recurrences.take(2).forEach { rec ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            tonalElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(CategoryPurpleBg),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Repeat, contentDescription = null, tint = CategoryPurple, modifier = Modifier.size(18.dp))
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(text = rec.productName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            text = "${rec.quantity} ${rec.unit} • ${rec.intervalLabel} • ${rec.habitualStore}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = BlueSurface
                                ) {
                                    Text(
                                        text = "R$ %.2f".format(rec.referencePrice),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = BlueVibrant,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Recent Audit Activity Feed
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Atividades Recentes",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                TextButton(onClick = onNavigateToHistory) {
                    Text("Ver histórico")
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                activityLogs.take(3).forEach { log ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 1.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = log.actorInitials.take(2).uppercase(),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = log.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "${log.actionType} • ${log.actorName}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FeatureShortcutCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        shadowElevation = 0.5.dp,
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 10.sp
                )
            }
        }
    }
}
