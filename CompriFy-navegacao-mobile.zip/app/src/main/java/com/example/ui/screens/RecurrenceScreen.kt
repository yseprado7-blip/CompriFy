package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Recurrence
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecurrenceScreen(
    recurrences: List<Recurrence>,
    onCreateRecurrence: (name: String, category: String, intervalDays: Int, intervalLabel: String, qty: Double, unit: String, store: String, refPrice: Double) -> Unit,
    onPostpone: (id: String, days: Int) -> Unit,
    onAddToList: (productName: String, qty: Double, unit: String, price: Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = CategoryPurple,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Nova Recorrência")
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp)
        ) {
            item {
                Text(
                    text = "Compras Recorrentes",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Lembretes e planejamento automático para itens de consumo contínuo",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (recurrences.isEmpty()) {
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Repeat, contentDescription = null, tint = Slate400, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Nenhuma compra recorrente cadastrada.", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            } else {
                items(recurrences) { rec ->
                    val isDue = rec.nextDate <= System.currentTimeMillis() + (2 * 24 * 60 * 60 * 1000L)

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(CategoryPurpleBg),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Repeat, contentDescription = null, tint = CategoryPurple, modifier = Modifier.size(18.dp))
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = rec.productName,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${rec.intervalLabel} • ${rec.category}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isDue) WarningAmberBg else BlueSurface
                                ) {
                                    Text(
                                        text = if (isDue) "Próxima da data" else "Em dia",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDue) WarningAmber else BlueVibrant,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = "Qtd Habitual", style = MaterialTheme.typography.labelSmall, color = Slate400)
                                    Text(text = "${rec.quantity} ${rec.unit}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text(text = "Preço Ref.", style = MaterialTheme.typography.labelSmall, color = Slate400)
                                    Text(text = "R$ %.2f".format(rec.referencePrice), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text(text = "Próxima Data", style = MaterialTheme.typography.labelSmall, color = Slate400)
                                    Text(
                                        text = dateFormat.format(Date(rec.nextDate)),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDue) WarningAmber else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Action buttons per requirement 12:
                            // "Na data prevista, perguntar se o usuário deseja: Criar ocorrência, Adiar, Pular, Concluir"
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { onPostpone(rec.id, 7) },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Adiar 7 dias", fontSize = 12.sp)
                                }

                                Button(
                                    onClick = {
                                        onAddToList(rec.productName, rec.quantity, rec.unit, rec.referencePrice)
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = NavyDark),
                                    modifier = Modifier.weight(1.3f)
                                ) {
                                    Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Gerar Ocorrência", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateRecurrenceDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { name, cat, days, label, q, u, st, pr ->
                onCreateRecurrence(name, cat, days, label, q, u, st, pr)
                showCreateDialog = false
            }
        )
    }
}

@Composable
fun CreateRecurrenceDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, cat: String, days: Int, label: String, qty: Double, unit: String, store: String, refPrice: Double) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Alimentação") }
    var intervalLabel by remember { mutableStateOf("Semanal") }
    var qtyText by remember { mutableStateOf("1") }
    var unit by remember { mutableStateOf("un") }
    var storeName by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("0.00") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nova Recorrência", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Produto *") },
                    placeholder = { Text("ex: Ovos Brancos 30 un") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Text("Frequência de Compra", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Semanal", "Quinzenal", "Mensal").forEach { l ->
                        FilterChip(
                            selected = intervalLabel == l,
                            onClick = { intervalLabel = l },
                            label = { Text(l) }
                        )
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { qtyText = it },
                        label = { Text("Qtd Habitual") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Unidade") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("Preço Ref. (R$)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = storeName,
                        onValueChange = { storeName = it },
                        label = { Text("Loja Habitual") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val days = when (intervalLabel) {
                        "Semanal" -> 7
                        "Quinzenal" -> 15
                        else -> 30
                    }
                    val q = qtyText.toDoubleOrNull() ?: 1.0
                    val pr = priceText.replace(",", ".").toDoubleOrNull() ?: 0.0
                    onCreate(name, category, days, intervalLabel, q, unit, storeName, pr)
                },
                enabled = name.isNotBlank()
            ) {
                Text("Agendar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}
