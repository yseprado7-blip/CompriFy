package com.example.ui.screens

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ActivityLog
import com.example.data.model.Purchase
import com.example.data.util.MoneyMath
import com.example.ui.components.ParticipantAvatar
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    logs: List<ActivityLog>,
    purchases: List<Purchase>,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf("Todos") }
    var selectedParticipant by remember { mutableStateOf<String?>("Todos") }
    var showExportSuccess by remember { mutableStateOf(false) }
    var exportError by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val dateFormat = SimpleDateFormat("dd/MM/yyyy • HH:mm", Locale.getDefault())

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            runCatching { writeHistoryCsv(context, uri, logs, purchases, dateFormat) }
                .onSuccess { showExportSuccess = true }
                .onFailure { exportError = it.message ?: "Não foi possível exportar o relatório." }
        }
    }

    val filteredLogs = remember(logs, selectedFilter, selectedParticipant) {
        logs.filter { log ->
            val matchType = when (selectedFilter) {
                "Compras" -> log.actionType.contains("Compra", ignoreCase = true)
                "Produtos" -> log.entityType == "Produto"
                "Listas" -> log.entityType == "Lista"
                else -> true
            }
            val matchParticipant = selectedParticipant == "Todos" || log.actorName.contains(selectedParticipant ?: "", ignoreCase = true)
            matchType && matchParticipant
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Histórico & Auditoria",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Rastreabilidade de todas as ações e compras do espaço",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                FilledTonalButton(
                    onClick = { exportLauncher.launch("comprify-relatorio.csv") },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Exportar", fontSize = 12.sp)
                }
            }
        }

        // Summary Statistics Cards
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "${purchases.count { it.status == "Finalizada" }}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = BlueVibrant)
                        Text(text = "Compras Efetivadas", style = MaterialTheme.typography.labelSmall, color = Slate400)
                    }
                    Box(modifier = Modifier.width(1.dp).height(36.dp).background(MaterialTheme.colorScheme.outline))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "R$ %.2f".format(MoneyMath.sum(purchases.filter { it.status == "Finalizada" }.map { it.finalAmount })), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = SuccessGreenDark)
                        Text(text = "Valor Total Pago", style = MaterialTheme.typography.labelSmall, color = Slate400)
                    }
                    Box(modifier = Modifier.width(1.dp).height(36.dp).background(MaterialTheme.colorScheme.outline))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "${logs.size}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = CategoryPurple)
                        Text(text = "Ações Registradas", style = MaterialTheme.typography.labelSmall, color = Slate400)
                    }
                }
            }
        }

        // Action Type Filter Chips
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Todos", "Compras", "Produtos", "Listas").forEach { f ->
                    FilterChip(
                        selected = selectedFilter == f,
                        onClick = { selectedFilter = f },
                        label = { Text(f) }
                    )
                }
            }
        }

        item {
            Text(
                text = "Linha do Tempo (${filteredLogs.size} eventos)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (filteredLogs.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.HistoryToggleOff, contentDescription = null, tint = Slate400, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Nenhum registro para este filtro.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        } else {
            items(filteredLogs) { log ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ParticipantAvatar(
                            name = log.actorName,
                            initials = log.actorInitials,
                            colorHex = "#2563EB",
                            size = 36.dp
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = log.actorName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )

                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    Text(
                                        text = log.actionType,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = log.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = dateFormat.format(Date(log.timestamp)),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }

    if (showExportSuccess) {
        AlertDialog(
            onDismissRequest = { showExportSuccess = false },
            icon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen) },
            title = { Text("Relatório Exportado com Sucesso") },
            text = {
                Text(
                    "O arquivo CSV com ${purchases.count { it.status == "Finalizada" }} compras finalizadas e ${logs.size} eventos foi salvo no local escolhido."
                )
            },
            confirmButton = {
                Button(onClick = { showExportSuccess = false }) { Text("OK") }
            }
        )
    }

    exportError?.let { message ->
        AlertDialog(
            onDismissRequest = { exportError = null },
            title = { Text("Falha na exportação") },
            text = { Text(message) },
            confirmButton = { Button(onClick = { exportError = null }) { Text("OK") } }
        )
    }
}

private fun writeHistoryCsv(
    context: Context,
    uri: Uri,
    logs: List<ActivityLog>,
    purchases: List<Purchase>,
    dateFormat: SimpleDateFormat
) {
    val output = context.contentResolver.openOutputStream(uri)
        ?: error("Não foi possível criar o arquivo selecionado.")
    output.bufferedWriter(Charsets.UTF_8).use { writer ->
        writer.write("Tipo;Data;Descrição;Responsável;Loja;Valor;Status\n")
        purchases.filter { it.status == "Finalizada" }.forEach { purchase ->
            writer.write(listOf(
                "Compra",
                dateFormat.format(java.util.Date(purchase.purchaseDate)),
                "Compra finalizada",
                purchase.responsibleParticipantName,
                purchase.storeName,
                "%.2f".format(java.util.Locale.US, purchase.finalAmount),
                purchase.status
            ).joinToString(";") { csvEscape(it) } + "\n")
        }
        logs.forEach { log ->
            writer.write(listOf(
                "Atividade",
                dateFormat.format(java.util.Date(log.timestamp)),
                log.description,
                log.actorName,
                "",
                "",
                log.actionType
            ).joinToString(";") { csvEscape(it) } + "\n")
        }
    }
}

private fun csvEscape(value: String): String = "\"${value.replace("\"", "\"\"")}\""
