package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.model.Profile

@Composable
fun SettingsScreen(
    currentProfile: Profile?,
    onExportBackup: (Uri) -> Unit,
    onImportBackup: (Uri) -> Unit,
    onUpdateProfileName: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val pendingImport = remember { mutableStateOf<Uri?>(null) }
    val profileName = remember(currentProfile?.name) { mutableStateOf(currentProfile?.name ?: "Meu perfil") }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) onExportBackup(uri) }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) pendingImport.value = uri }

    Column(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Configurações", style = MaterialTheme.typography.headlineSmall)
        Text("Perfil deste aparelho", style = MaterialTheme.typography.titleMedium)
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                OutlinedTextField(
                    value = profileName.value,
                    onValueChange = { profileName.value = it },
                    label = { Text("Nome do perfil") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { onUpdateProfileName(profileName.value) },
                    enabled = profileName.value.isNotBlank() && profileName.value != currentProfile?.name
                ) { Text("Salvar nome") }
                Spacer(Modifier.height(4.dp))
                Text("Os dados são armazenados localmente neste celular.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Privacidade e funcionamento", style = MaterialTheme.typography.titleMedium)
                Text("O CompriFy não usa conta online, servidor ou sincronização automática. Cada outro aparelho terá um banco de dados separado.")
                Text("As funções principais podem ser usadas sem internet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text("Backup e restauração", style = MaterialTheme.typography.titleMedium)
        Text("Exporte um arquivo JSON para guardar seus dados ou transfira manualmente para outro aparelho.")
        Button(
            onClick = { exportLauncher.launch("comprify-backup.json") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Exportar backup")
        }
        OutlinedButton(
            onClick = { importLauncher.launch(arrayOf("application/json", "text/*")) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Restaurar backup")
        }
        Text(
            "A restauração substitui os dados atuais deste aparelho. Faça um backup antes de continuar.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.error
        )
    }

    pendingImport.value?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingImport.value = null },
            title = { Text("Restaurar backup?") },
            text = { Text("Esta ação substituirá as listas, produtos, compras, orçamentos e demais dados deste celular. Deseja continuar?") },
            confirmButton = {
                TextButton(onClick = {
                    onImportBackup(uri)
                    pendingImport.value = null
                }) { Text("Restaurar") }
            },
            dismissButton = {
                TextButton(onClick = { pendingImport.value = null }) { Text("Cancelar") }
            }
        )
    }
}
