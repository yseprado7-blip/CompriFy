package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.BlueSurface
import com.example.ui.theme.NavyPrimary

val PRESET_PRODUCT_ICONS = listOf(
    Pair("🌾", "Grãos"),
    Pair("🫘", "Feijão"),
    Pair("🥛", "Leite"),
    Pair("🥩", "Carnes"),
    Pair("🍗", "Aves"),
    Pair("🐟", "Peixes"),
    Pair("🧀", "Queijos"),
    Pair("🍞", "Pães"),
    Pair("🫒", "Azeites"),
    Pair("🍝", "Massas"),
    Pair("🍎", "Frutas"),
    Pair("🥦", "Verduras"),
    Pair("🧅", "Temperos"),
    Pair("🧃", "Bebidas"),
    Pair("☕", "Café"),
    Pair("🍪", "Doces"),
    Pair("🧼", "Lavanderia"),
    Pair("🫧", "Detergente"),
    Pair("🧴", "Shampoo"),
    Pair("🪥", "Dental"),
    Pair("🧻", "Papel"),
    Pair("🧊", "Congelados"),
    Pair("🐶", "Pet"),
    Pair("📦", "Outros")
)

@Composable
fun ProductThumbnail(
    imageUrl: String = "",
    iconEmoji: String = "📦",
    category: String = "",
    size: Dp = 48.dp,
    modifier: Modifier = Modifier
) {
    val bgColor = when {
        category.contains("Aliment", ignoreCase = true) -> Color(0xFFFEF3C7)
        category.contains("Limp", ignoreCase = true) -> Color(0xFFE0F2FE)
        category.contains("Higien", ignoreCase = true) -> Color(0xFFF3E8FF)
        else -> BlueSurface
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor),
        contentAlignment = Alignment.Center
    ) {
        if (imageUrl.isNotBlank()) {
            AsyncImage(
                model = imageUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text(
                text = if (iconEmoji.isNotBlank()) iconEmoji else "📦",
                fontSize = (size.value * 0.5f).sp
            )
        }
    }
}

@Composable
fun ProductImageSelector(
    selectedEmoji: String,
    selectedImageUrl: String,
    onSelectEmoji: (String) -> Unit,
    onSelectImageUrl: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showUrlInput by remember { mutableStateOf(selectedImageUrl.isNotBlank()) }

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "Imagem / Ícone do Produto",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(6.dp))

        // Preset Grid of 24 Shopping Icons
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 44.dp),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 140.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(PRESET_PRODUCT_ICONS) { (emoji, label) ->
                val isSelected = selectedEmoji == emoji && selectedImageUrl.isBlank()
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                    modifier = Modifier
                        .size(44.dp)
                        .clickable {
                            onSelectEmoji(emoji)
                            onSelectImageUrl("")
                        }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(text = emoji, fontSize = 20.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Option to enter remote image URL
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable { showUrlInput = !showUrlInput }
        ) {
            Icon(Icons.Default.Image, contentDescription = null, tint = NavyPrimary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (showUrlInput) "Ocultar URL de Imagem da Web" else "Adicionar URL de Imagem Externa (Opcional)",
                style = MaterialTheme.typography.labelSmall,
                color = NavyPrimary,
                fontWeight = FontWeight.SemiBold
            )
        }

        if (showUrlInput) {
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = selectedImageUrl,
                onValueChange = onSelectImageUrl,
                label = { Text("URL da Imagem (https://...)") },
                placeholder = { Text("https://exemplo.com/arroz.jpg") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }
    }
}
