# CompriFy — Planeje • Compare • Compre

Aplicativo Android nativo para organização de compras domésticas.

## Arquitetura

- Kotlin + Jetpack Compose + Material 3.
- Room/SQLite como banco de dados local.
- Cada instalação possui seus próprios dados; não existe login, servidor ou sincronização automática entre celulares.
- Exportação e restauração manual de backup JSON.
- As funções de cadastro, listas, compras, catálogo, preços e orçamento funcionam localmente.

## Requisitos de compilação

- JDK 17 ou superior compatível com o Android Gradle Plugin usado pelo projeto.
- Android SDK 36.
- Gradle 9.3.1.

## Compilar APK de teste

```bash
gradle :app:assembleDebug
```

O APK será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Dados e backup

O banco é criado no próprio aparelho. O backup pode ser exportado como JSON em Configurações e restaurado manualmente em outra instalação. Restaurar substitui os dados atuais do aparelho de destino.

## Observações

- A prévia de widgets dentro do app é uma demonstração visual; não representa widgets nativos instaláveis na tela inicial.
- O ZIP de origem foi recuperado de uma exportação anterior do AI Studio. O ID do projeto indicado no README original divergia do link mais recente informado pela proprietária; portanto, esta base deve ser comparada com a versão mais recente quando ela estiver acessível.
- A compilação e os testes em dispositivo precisam ser executados antes de distribuir o APK.

## Importação pelo GitHub

O workflow `prepare-and-build.yml` aceita o arquivo `comprify-source.zip` na raiz. Ao enviar esse arquivo, o GitHub Actions extrai o código, grava os arquivos no repositório, executa os testes e tenta gerar o APK de depuração. Também pode ser iniciado manualmente pela aba Actions.
